// Automatic map downloads for the browser build. Bundled into openjkdf2.js
// with --pre-js (cmake_modules/plat_wasm.cmake), so it always matches the
// engine it ships with.
//
// When a player joins a game whose episode GOB they don't have, or have a
// different version of, their tab gets it from the host's tab: over a second
// WebRTC data channel when the direct link is up, else through the lobby as
// binary frames it forwards like game packets (stdComm_WSRelay.c). Nothing is
// stored on or served from the lobby.
//
// Original game files never cross the wire. The original episodes are never
// offered, and any file inside a custom GOB that is byte-for-byte identical
// to a file in the host's retail GOBs, or to a whole retail GOB, is replaced
// by a reference (offset, size, SHA-256). The joiner fills those parts in
// from its own retail GOBs and checks the rebuilt GOB against the host's
// SHA-256 before installing it. A GOB made only of retail files (a renamed
// original episode) isn't sent. A joiner whose game has other versions of
// some of those files, such as from a fan pack, leaves them out of the map
// and plays it with its own (ownVersions).
//
// Downloaded maps are kept in IndexedDB and written into episode/ before the
// engine starts, so they're there next time and can be hosted.
//
// The same transfer also carries the host's mod (mods.js): KIND_MOD frames
// ask for and send it, KIND_MAP frames the map.
//
// And the next level of the host's playlist (src/Main/jkPlaylist.c): when a
// level ends, the host offers the next level's GOB as KIND_NEXT (next.host),
// and the others start getting it if they don't have it (next.fetch): a Level
// Library level from the site (library.js, gobFromSite) when the site has
// one with the host's SHA-256, else from the host as a map. They say how far
// along they are with STATUS frames, so the host's score screen can wait for
// them; the engine shows the progress itself, so no panel comes up.
//
// Every frame starts like a relay game packet, with idFrom and idTo (u32),
// then MAGIC, a type byte, a version byte and a kind byte, padded to 16 bytes:
//   joiner -> host   INFO_REQ
//                    CHUNK_REQ  <id:8> <chunkSize u32> <first u32> <count u32>
//                    BLOCK_REQ  <id:8> <first u32> <count u32> <partSize u32>
//                               <accept u8> <pad:3>
//                    STATUS     <JSON: n (the GOB's name), s (STATE_*), p (0 to 1,
//                                or -1)>, KIND_NEXT only
//   host -> joiner   INFO       <JSON: status, name, ext, size, sha256,
//                                streamSize, refsBytes, z, streamSha256>
//                    CHUNK      <id:8> <index u32> <data>
//                    BLOCK      <id:8> <block u32> <zlen u32> <at u32>
//                               <codec u8> <pad:3> <data>
// <id> is the first 8 bytes of the file's SHA-256, so chunks of another file
// are never mixed in. The stream the chunks cut up is the reference table (u32
// count, then u32 offset, u32 size and a 32-byte SHA-256 per reference),
// followed by the file's bytes outside the references, in order; a map's
// host with references says the stream's SHA-256 as streamSha256. Game packets
// start with a DSS message id below DSS_MAX (66), so their byte 8 is never
// MAGIC's first byte ('J', 74). Pages from before mods leave the kind byte at
// 0 and ignore it, so they only ever answer for their map.
//
// A host that says z (BLOCK_BYTES) in its INFO also sends the stream in
// blocks of that many bytes, each squeezed with deflate where the joiner can
// unsqueeze it (accept 1) and that makes it smaller (codec 1, else 0, as
// is), and cut into parts of partSize: zlen is the block's size as sent and
// at where the part goes in it. Mods are mostly text and uncompressed
// textures and sounds: SBX-JK Continuum's 305 MiB GOB goes as 82 MB. The host
// squeezes blocks as they're asked for, in a worker, and keeps them for the
// next joiner. The joiner asks for a few blocks at a time on each way to the
// host it has (lanes): the map channel, the extra links the network code
// opens for a transfer (stdComm_WSRelay.c, net.mapBulk), or the relay, and
// puts each block in place as it comes, so the file is only in memory once.
// A browser's data channel carries only so much at a time however fast the
// connection (about 2 MB/s at a 50 ms round trip), and each link has its own,
// so four go about four times as fast. Pages from before blocks only ask for
// chunks, which the host still sends, and a host from before them never says
// z, so the joiner asks it for chunks.

(function() {
    var MAGIC = [0x4A, 0x4B, 0x4D, 0x54]; // "JKMT"
    var VERSION = 1;
    var HEADER = 16;
    var T_INFO_REQ = 1, T_INFO = 2, T_CHUNK_REQ = 3, T_CHUNK = 4, T_BLOCK_REQ = 5, T_BLOCK = 6, T_STATUS = 7;
    var KIND_MAP = 0, KIND_MOD = 1, KIND_NEXT = 2;
    // A joiner getting the next level says how far along it is at most this often.
    var STATUS_MS = 1000;

    // What can be sent: as much as a browser tab can comfortably hold twice
    // over, once as the file and once while checking it.
    var MAX_MAP_BYTES = 1024 * 1024 * 1024;
    var MAX_STORED_BYTES = 2048 * 1024 * 1024;
    var MAX_REFS = 65536;
    var REF_BYTES = 40;
    // The stream is copied whole to be hashed for streamSha256.
    var MAX_STREAM_HASH_BYTES = 256 * 1024 * 1024;
    // The lobby closes sockets that send more than 64 KiB in one message
    // (jkdf2mp-bb-server cloudflare/src/lobby.js), and data channel messages
    // are best kept small.
    var CHUNK_DIRECT = 16 * 1024;
    var CHUNK_RELAY = 48 * 1024;
    var WINDOW_BYTES = 1024 * 1024;
    var MAX_CHUNKS_PER_REQ = 128;
    // Blocks: every browser takes data channel messages of 64 KiB and more.
    var BLOCK_BYTES = 1024 * 1024;
    var PART_DIRECT = 64 * 1024;
    var PART_RELAY = 48 * 1024;
    var BLOCK_HEADER = 24;
    var MAX_BLOCKS_PER_REQ = 4;
    // Blocks asked for and not yet in, on each way to the host: through the
    // lobby, at most twice what the chunks had out at once, and a quarter of
    // that for most mods.
    var BLOCKS_DIRECT = 3;
    var BLOCKS_RELAY = 2;
    // Blocks squeezed ahead of the joiner's asking.
    var BLOCKS_AHEAD = 6;
    var CODEC_STORED = 0, CODEC_DEFLATE = 1;
    var DIRECT_WAIT_MS = 3000;
    var INFO_RESEND_MS = 5000;
    var INFO_TIMEOUT_MS = 20000;
    var CHUNK_RESEND_MS = 5000;
    var STALL_MS = 15000;
    var CHECKING_UI_MS = 600;

    // STATE_RESTART: the engine has to restart to use what was fetched (a mod).
    var STATE_BUSY = 0, STATE_READY = 1, STATE_FAILED = 2, STATE_RESTART = 3;

    var GOB_ENTRY = 136; // u32 offset, u32 size, char[128] name (Win95/stdGob.h)

    // The original episodes, by name, and the retail GOBs whose files are
    // never sent (src/Main/InstallHelper.c).
    var RETAIL_EPISODES = ['jk1', 'jk1ctf', 'jk1mp', 'jk1demo', 'jk1mpdem', 'jk1mpdemo',
                           'jkm', 'jkm_kfy', 'jkm_mp', 'jkm_saber'];
    var RETAIL_FILES = {
        gob: ['episode/JK1.gob', 'episode/JK1CTF.gob', 'episode/JK1MP.gob',
              'episode/jk1demo.gob', 'episode/jk1mpdem.gob', 'episode/jk1mpdemo.gob',
              'resource/Res1hi.gob', 'resource/Res1low.gob', 'resource/Res2.gob',
              'resource/res1demo.gob'],
        goo: ['episode/JKM.goo', 'episode/JKM_KFY.goo', 'episode/JKM_MP.goo', 'episode/JKM_SABER.goo',
              'resource/Jkmres.goo', 'resource/JKMsndLO.goo']
    };

    function isRetailEpisode(name) {
        return RETAIL_EPISODES.indexOf(String(name).toLowerCase()) >= 0;
    }

    function gameOfEpisode(name) {
        return /^jkm/i.test(name) ? 'Mysteries of the Sith' : 'Jedi Knight';
    }

    // Episode names come from the other player, and become a file name here:
    // at most 31 characters (jkMultiEntry), nothing Windows wouldn't allow in
    // a file name, and no way out of episode/.
    function validEpisodeName(name) {
        return typeof name === 'string' && /^[^\/\\:*?"<>|\x00-\x1f.][^\/\\:*?"<>|\x00-\x1f]{0,30}$/.test(name) &&
               name.indexOf('..') < 0;
    }

    function validExt(ext) {
        return ext === 'gob' || ext === 'goo';
    }

    function toHex(buf) {
        var b = new Uint8Array(buf);
        var s = '';
        for (var i = 0; i < b.length; i++)
            s += (b[i] < 16 ? '0' : '') + b[i].toString(16);
        return s;
    }

    function fromHex(hex, out, at) {
        for (var i = 0; i < 32; i++)
            out[at + i] = parseInt(hex.substr(i * 2, 2), 16);
    }

    async function sha256(bytes) {
        return toHex(await crypto.subtle.digest('SHA-256', bytes));
    }

    // Bytes made of pieces back to back, such as a mod's pack (its header,
    // each file as the file system holds it, its table) or the stream sent
    // for a file, so neither is copied whole to be sent.
    function pieces(parts) {
        parts = parts.filter(function(p) { return p.length > 0; });
        var starts = [];
        var length = 0;
        for (var p of parts) {
            starts.push(length);
            length += p.length;
        }
        function find(offset) {
            var lo = 0, hi = parts.length - 1;
            while (lo < hi) {
                var mid = (lo + hi + 1) >> 1;
                if (starts[mid] <= offset)
                    lo = mid;
                else
                    hi = mid - 1;
            }
            return lo;
        }
        // The views that make up n bytes from offset.
        function views(offset, n) {
            var out = [];
            if (n <= 0)
                return out;
            for (var i = find(offset), at = offset - starts[i]; n > 0; i++, at = 0) {
                var take = Math.min(parts[i].length - at, n);
                out.push(parts[i].subarray(at, at + take));
                n -= take;
            }
            return out;
        }
        // n bytes from offset: a view where they're in one piece, else a copy.
        function read(offset, n) {
            var v = views(offset, n);
            if (v.length === 1)
                return v[0];
            var out = new Uint8Array(n);
            var at = 0;
            for (var x of v) {
                out.set(x, at);
                at += x.length;
            }
            return out;
        }
        return {
            length: length,
            views: views,
            read: read,
            bytes: function() { return read(0, length); }
        };
    }

    // ---- GOB tools. They read through read(offset, length) -> Uint8Array, so
    // the same code works on a GOB in memory and on one in the file system.

    function memReader(bytes) {
        return function(offset, length) { return bytes.subarray(offset, offset + length); };
    }

    // The file list of a GOB, or null if it isn't one.
    function parseGob(read, fileSize) {
        if (fileSize < 16)
            return null;
        var head = read(0, 12);
        if (head[0] !== 0x47 || head[1] !== 0x4F || head[2] !== 0x42 || head[3] !== 0x20) // "GOB "
            return null;
        var hv = new DataView(head.buffer, head.byteOffset, 12);
        if (hv.getUint32(4, true) !== 20)
            return null;
        var tableOffs = hv.getUint32(8, true);
        if (tableOffs + 4 > fileSize)
            return null;
        var countBytes = read(tableOffs, 4);
        var count = new DataView(countBytes.buffer, countBytes.byteOffset, 4).getUint32(0, true);
        if (tableOffs + 4 + count * GOB_ENTRY > fileSize)
            return null;
        var table = read(tableOffs + 4, count * GOB_ENTRY);
        var tv = new DataView(table.buffer, table.byteOffset, table.length);
        var entries = [];
        for (var i = 0; i < count; i++) {
            var at = i * GOB_ENTRY;
            var offset = tv.getUint32(at, true);
            var size = tv.getInt32(at + 4, true);
            if (size < 0 || offset + size > fileSize)
                return null;
            var name = '';
            for (var j = 0; j < 128 && table[at + 8 + j]; j++)
                name += String.fromCharCode(table[at + 8 + j]);
            entries.push({ offset: offset, size: size, name: name });
        }
        return { entries: entries };
    }

    // Finds files by content among a set of GOBs. sources is a list of
    // { read, entries }; hashes are worked out per size, only when a file of
    // that size is looked up.
    function contentIndex(sources) {
        var bySize = new Map();
        sources.forEach(function(src) {
            src.entries.forEach(function(e) {
                if (e.size <= 0)
                    return;
                var list = bySize.get(e.size);
                if (!list)
                    bySize.set(e.size, list = []);
                list.push({ src: src, entry: e });
            });
        });
        var hashed = new Map(); // size -> Promise<Map(sha -> candidate)>

        function hashesOfSize(size) {
            var p = hashed.get(size);
            if (!p) {
                p = (async function() {
                    var m = new Map();
                    for (var c of bySize.get(size) || []) {
                        var h = await sha256(c.src.read(c.entry.offset, c.entry.size));
                        if (!m.has(h))
                            m.set(h, c);
                    }
                    return m;
                })();
                hashed.set(size, p);
            }
            return p;
        }

        return {
            hasSize: function(size) { return bySize.has(size); },
            find: async function(size, sha) {
                if (!bySize.has(size))
                    return null;
                return (await hashesOfSize(size)).get(sha) || null;
            }
        };
    }

    // Splits a custom GOB into what may be sent: the references to retail
    // files and the bytes outside them.
    async function planShare(gob, retailSources) {
        var dir = parseGob(memReader(gob), gob.length);
        if (!dir)
            return { ok: false, reason: 'not-gob' };
        return planShareRanges(gob, dir.entries, retailSources);
    }

    // The same for any bytes, in one piece or in pieces(): each range
    // ({ offset, size }) that is a copy of a file in the retail GOBs becomes
    // a reference. The stream is in pieces too, views of the bytes given.
    async function planShareRanges(gob, ranges, retailSources) {
        var src = gob.views ? gob : pieces([gob]);
        var index = contentIndex(retailSources);
        var refs = [];
        var custom = 0;
        for (var e of ranges) {
            if (e.size <= 0)
                continue;
            var hit = null;
            var sha = null;
            if (index.hasSize(e.size)) {
                sha = await sha256(src.read(e.offset, e.size));
                hit = await index.find(e.size, sha);
            }
            if (hit)
                refs.push({ offset: e.offset, size: e.size, sha: sha });
            else
                custom++;
        }
        if (!custom)
            return { ok: false, reason: 'retail-only' };

        // A reference inside another (a file of a nested GOB that is itself a
        // copy, or a second entry for the same bytes) adds nothing.
        refs.sort(function(a, b) { return a.offset - b.offset || b.size - a.size; });
        var kept = [];
        var end = 0;
        for (var r of refs) {
            if (kept.length && r.offset + r.size <= end)
                continue;
            kept.push(r);
            end = Math.max(end, r.offset + r.size);
        }
        refs = kept;
        if (refs.length > MAX_REFS)
            return { ok: false, reason: 'too-many-files' };

        var table = refTable(refs);
        var refsBytes = table.length;

        // Entries can share or overlap bytes; the parts that are copies of
        // retail files are the union of the references.
        var parts = [table];
        var pos = 0;
        function inline(from, to) {
            for (var v of src.views(from, to - from))
                parts.push(v);
        }
        for (var r of refs) {
            if (r.offset > pos)
                inline(pos, r.offset);
            pos = Math.max(pos, r.offset + r.size);
        }
        if (pos < src.length)
            inline(pos, src.length);
        return { ok: true, stream: pieces(parts), refsBytes: refsBytes, refs: refs.length };
    }

    // The reference table a stream starts with.
    function refTable(refs) {
        var table = new Uint8Array(4 + refs.length * REF_BYTES);
        var tv = new DataView(table.buffer);
        tv.setUint32(0, refs.length, true);
        refs.forEach(function(r, i) {
            var at = 4 + i * REF_BYTES;
            tv.setUint32(at, r.offset, true);
            tv.setUint32(at + 4, r.size, true);
            fromHex(r.sha, table, at + 8);
        });
        return table;
    }

    // The reference table at the start of a stream, or null if it doesn't
    // fit what the host said.
    function parseRefs(head, info) {
        var sv = new DataView(head.buffer, head.byteOffset, head.length);
        var count = sv.getUint32(0, true);
        if (count > MAX_REFS || 4 + count * REF_BYTES !== info.refsBytes || head.length < info.refsBytes)
            return null;
        var refs = [];
        for (var i = 0; i < count; i++) {
            var at = 4 + i * REF_BYTES;
            var r = { offset: sv.getUint32(at, true), size: sv.getUint32(at + 4, true),
                      sha: toHex(head.subarray(at + 8, at + 40)) };
            if (!r.size || r.offset + r.size > info.size || (refs.length && r.offset < refs[refs.length - 1].offset))
                return null;
            refs.push(r);
        }
        return refs;
    }

    // Copies the references' bytes in from the joiner's own retail GOBs, then
    // checks the whole against the host's SHA-256. With own set (a map), a
    // reference the joiner has no exact copy of can be left to its own
    // version of the file instead (ownVersions).
    async function fillRefs(out, refs, info, retailSources, own) {
        var index = contentIndex(retailSources);
        var missing = [];
        for (var r of refs) {
            var hit = await index.find(r.size, r.sha);
            if (hit)
                out.set(hit.src.read(hit.entry.offset, hit.entry.size), r.offset);
            else
                missing.push(r);
        }
        if (missing.length)
            return own ? ownVersions(out, refs, missing, info, retailSources) : { ok: false, reason: 'missing-retail' };
        if (await sha256(out) !== info.sha256)
            return { ok: false, reason: 'mismatch' };
        return { ok: true, bytes: out };
    }

    // GOB entry names as the engine looks them up (stdGob_FileOpen).
    function gobName(name) {
        return name.toLowerCase().replace(/\//g, '\\');
    }

    // A fan pack such as MotS Remastered replaces some of the game's own
    // files (the JKMsndLO.goo its 3.0 installer puts in resource/ has other
    // versions of 1,002 of the original 1,222 sounds), so a map that bundles
    // a copy of an original file can't be rebuilt byte for byte from that
    // player's GOBs. It doesn't need to be: each such file is left out of the
    // map, and the engine opens the player's own version of it from the
    // game's resource GOBs instead, as it does in the original levels. Only
    // files the joiner has under the same name in a GOB the engine always
    // loads (resource/) are left out, and only whole entries; anything else
    // is still missing-retail. The rest of the GOB is checked against the
    // SHA-256 of the stream the host sent (streamSha256: the reference table
    // and the bytes outside it), since the whole file's can't match. Nothing
    // more is asked of the host, and no original file is sent.
    async function ownVersions(out, refs, missing, info, retailSources) {
        var hashed = typeof info.streamSha256 === 'string' && /^[0-9a-f]{64}$/.test(info.streamSha256);
        if (hashed && await sha256(sentStream(out, refs).bytes()) !== info.streamSha256)
            return { ok: false, reason: 'mismatch' };
        var mine = {}, episodes = {};
        retailSources.forEach(function(src) {
            src.entries.forEach(function(e) {
                if (e.name && !src.spare)
                    (src.always ? mine : episodes)[gobName(e.name)] = true;
            });
        });
        var dir = parseGob(memReader(out), out.length);
        if (!dir)
            return { ok: false, reason: hashed ? 'not-gob' : 'missing-retail' };
        var keep = [], lacking = [];
        for (var e of dir.entries) {
            var hits = missing.filter(function(m) {
                return e.size > 0 && e.offset < m.offset + m.size && m.offset < e.offset + e.size;
            });
            if (!hits.length) {
                keep.push(e);
                continue;
            }
            var inside = hits.length === 1 && hits[0].offset <= e.offset &&
                         e.offset + e.size <= hits[0].offset + hits[0].size;
            if (!inside || !mine[gobName(e.name)])
                lacking.push(e.name + (!inside ? ' (part of a file)' : episodes[gobName(e.name)] ? ' (only in an episode GOB)' : ''));
        }
        // Which ones, for whoever reads the console.
        if (lacking.length) {
            console.log('OpenJKDF2: original files in this map that this game folder has no copy of: ' +
                        lacking.slice(0, 20).join(', ') + (lacking.length > 20 ? ' and ' + (lacking.length - 20) + ' more' : ''));
            return { ok: false, reason: 'missing-retail' };
        }
        // A host from before this can't vouch for what it sent.
        if (!hashed)
            return { ok: false, reason: 'retail-changed' };
        return { ok: true, bytes: makeGob(out, keep), own: dir.entries.length - keep.length };
    }

    // What the host sent for a GOB: its reference table, then its bytes
    // outside the references, in order, as planShareRanges cut it.
    function sentStream(out, refs) {
        var parts = [refTable(refs)];
        var pos = 0;
        for (var r of refs) {
            if (r.offset > pos)
                parts.push(out.subarray(pos, r.offset));
            pos = Math.max(pos, r.offset + r.size);
        }
        if (pos < out.length)
            parts.push(out.subarray(pos));
        return pieces(parts);
    }

    // A GOB of the given entries of another (bytes): its table first, as the
    // game's own GOBs have it, then each entry's bytes, once for entries
    // that share them.
    function makeGob(bytes, entries) {
        var tableAt = 12;
        var at = tableAt + 4 + entries.length * GOB_ENTRY;
        var placed = new Map(); // "offset/size" -> where it goes
        var spans = [];
        var where = entries.map(function(e) {
            var k = e.offset + '/' + e.size;
            if (!placed.has(k)) {
                placed.set(k, at);
                spans.push({ from: e.offset, to: at, size: e.size });
                at += e.size;
            }
            return placed.get(k);
        });
        var gob = new Uint8Array(at);
        var v = new DataView(gob.buffer);
        gob.set([0x47, 0x4F, 0x42, 0x20]); // "GOB "
        v.setUint32(4, 20, true);
        v.setUint32(8, tableAt, true);
        v.setUint32(tableAt, entries.length, true);
        entries.forEach(function(e, i) {
            var t = tableAt + 4 + i * GOB_ENTRY;
            v.setUint32(t, where[i], true);
            v.setUint32(t + 4, e.size, true);
            for (var j = 0; j < e.name.length && j < 128; j++)
                gob[t + 8 + j] = e.name.charCodeAt(j) & 0xFF;
        });
        for (var s of spans)
            gob.set(bytes.subarray(s.from, s.from + s.size), s.to);
        return gob;
    }

    // Puts a GOB back together from a stream and the joiner's own retail
    // GOBs, and checks it against the host's SHA-256.
    async function rebuild(info, stream, retailSources, own) {
        if (stream.length !== info.streamSize || info.refsBytes < 4 || info.refsBytes > stream.length)
            return { ok: false, reason: 'corrupt' };
        var refs = parseRefs(stream, info);
        if (!refs)
            return { ok: false, reason: 'corrupt' };

        var out = new Uint8Array(info.size);
        var src = info.refsBytes;
        var pos = 0;
        for (var r of refs) {
            if (r.offset > pos) {
                var n = r.offset - pos;
                if (src + n > stream.length)
                    return { ok: false, reason: 'corrupt' };
                out.set(stream.subarray(src, src + n), pos);
                src += n;
            }
            pos = Math.max(pos, r.offset + r.size);
        }
        if (stream.length - src !== info.size - pos)
            return { ok: false, reason: 'corrupt' };
        out.set(stream.subarray(src), pos);
        return fillRefs(out, refs, info, retailSources, own);
    }

    // The same as the stream comes in, a piece at a time in any order (put),
    // each straight into place, so the GOB is only in memory once. Pieces
    // before the reference table is whole wait for it. finish() resolves as
    // rebuild() does, once every byte has been put.
    function rebuilder(info, retailSources, own) {
        var head = new Uint8Array(info.refsBytes);
        var headLeft = info.refsBytes;
        var early = [];
        var refs = null, gaps = null, out = null;
        var placed = 0;

        // Where each run of the stream after the table goes in the GOB: the
        // bytes between references, in order.
        function plan() {
            refs = parseRefs(head, info);
            if (!refs)
                throw fail('corrupt');
            gaps = [];
            var s = info.refsBytes, pos = 0;
            for (var r of refs) {
                if (r.offset > pos) {
                    gaps.push({ s: s, p: pos, n: r.offset - pos });
                    s += r.offset - pos;
                }
                pos = Math.max(pos, r.offset + r.size);
            }
            if (pos < info.size) {
                gaps.push({ s: s, p: pos, n: info.size - pos });
                s += info.size - pos;
            }
            if (s !== info.streamSize)
                throw fail('corrupt');
            try {
                out = new Uint8Array(info.size);
            } catch (e) {
                throw fail('memory');
            }
        }

        function scatter(s, bytes) {
            var end = s + bytes.length;
            var lo = 0, hi = gaps.length;
            while (lo < hi) {
                var mid = (lo + hi) >> 1;
                if (gaps[mid].s + gaps[mid].n <= s)
                    lo = mid + 1;
                else
                    hi = mid;
            }
            for (var i = lo; i < gaps.length && gaps[i].s < end; i++) {
                var g = gaps[i];
                var a = Math.max(s, g.s), b = Math.min(end, g.s + g.n);
                out.set(bytes.subarray(a - s, b - s), g.p + a - g.s);
                placed += b - a;
            }
        }

        return {
            // The stream's bytes from offset s, each given once.
            put: function(s, bytes) {
                if (gaps) {
                    scatter(s, bytes);
                    return;
                }
                if (s < info.refsBytes) {
                    var n = Math.min(bytes.length, info.refsBytes - s);
                    head.set(bytes.subarray(0, n), s);
                    headLeft -= n;
                }
                early.push({ s: s, bytes: bytes });
                if (headLeft > 0)
                    return;
                plan();
                var waiting = early;
                early = null;
                for (var w of waiting)
                    scatter(w.s, w.bytes);
            },
            finish: function() {
                if (!gaps || placed !== info.streamSize - info.refsBytes)
                    return Promise.resolve({ ok: false, reason: 'corrupt' });
                return fillRefs(out, refs, info, retailSources, own);
            }
        };
    }

    var lib = { parseGob: parseGob, planShare: planShare, planShareRanges: planShareRanges,
                rebuild: rebuild, rebuilder: rebuilder, pieces: pieces, sha256: sha256, toHex: toHex,
                isRetailEpisode: isRetailEpisode, validEpisodeName: validEpisodeName };

    // ---- The file system side.

    function FS() { return Module.FS; }

    // MEMFS is case-sensitive, Windows game folders aren't: find "a/b.gob"
    // under root whatever its case.
    function findPath(root, rel) {
        var fs = FS();
        var path = root;
        var parts = rel.split('/');
        for (var i = 0; i < parts.length; i++) {
            var names;
            try { names = fs.readdir(path); } catch (e) { return null; }
            var want = parts[i].toLowerCase();
            var found = null;
            for (var n of names) {
                if (n.toLowerCase() === want) { found = n; break; }
            }
            if (!found)
                return null;
            path = path + '/' + found;
        }
        return path;
    }

    function isFile(path) {
        try { return FS().isFile(FS().stat(path).mode); } catch (e) { return false; }
    }

    // A file's bytes as the file system holds them: MEMFS keeps each file in
    // one array, so this is a view of it rather than a copy where it can be.
    function fileBytes(path) {
        var fs = FS();
        try {
            var node = fs.lookupPath(path).node;
            if (node.contents instanceof Uint8Array && typeof node.usedBytes === 'number')
                return node.contents.subarray(0, node.usedBytes);
        } catch (e) {}
        return fs.readFile(path);
    }

    function fileReader(path) {
        var fs = FS();
        return function(offset, length) {
            var buf = new Uint8Array(length);
            var stream = fs.open(path, 'r');
            try { fs.read(stream, buf, 0, length, offset); } finally { fs.close(stream); }
            return buf;
        };
    }

    // The retail GOBs this install has, with their file lists. always: one
    // in resource/, which the engine loads whatever the level. spare: a copy
    // of one in a folder in resource/, which the engine never loads, kept
    // when a fan pack replaced it (the MotS Remastered pack keeps the
    // original JKMsndLO.goo in resource/Backup Sounds/; the page reads it,
    // see isSpareRetail in index.html). Its files are found by content only.
    function retailSources(root, ext) {
        var out = [];
        var add = function(path, flags) {
            var read = fileReader(path);
            var size = FS().stat(path).size;
            var dir = parseGob(read, size);
            // The whole GOB too, for a mod that carries a copy of one.
            if (dir)
                out.push(Object.assign({ read: read, entries: dir.entries.concat([{ offset: 0, size: size, name: '' }]) },
                                       flags));
        };
        for (var rel of RETAIL_FILES[ext] || []) {
            var path = findPath(root, rel);
            if (path && isFile(path))
                add(path, { always: /^resource\//.test(rel) });
        }
        for (var path of spareRetail(root, ext))
            add(path, { always: false, spare: true });
        return out;
    }

    function spareRetail(root, ext) {
        var fs = FS();
        var resource = findPath(root, 'resource');
        var names = (RETAIL_FILES[ext] || []).filter(function(rel) { return /^resource\//.test(rel); })
                                             .map(function(rel) { return rel.substring(9).toLowerCase(); });
        var out = [];
        if (!resource)
            return out;
        for (var sub of fs.readdir(resource)) {
            var dir = resource + '/' + sub;
            if (sub === '.' || sub === '..' || isFile(dir))
                continue;
            var list;
            try { list = fs.readdir(dir); } catch (e) { continue; }
            for (var n of list) {
                if (names.indexOf(n.toLowerCase()) >= 0 && isFile(dir + '/' + n))
                    out.push(dir + '/' + n);
            }
        }
        return out;
    }

    function gameRoot() {
        return FS().cwd().replace(/\/+$/, '');
    }

    // Into the episode folder the engine already reads, whatever its case: a
    // second one spelled differently would hide one of them (see index.html).
    function install(root, name, ext, bytes) {
        var fs = FS();
        var dir = findPath(root, 'episode');
        if (!dir) {
            dir = root + '/episode';
            fs.mkdirTree(dir);
        }
        var old = findPath(root, 'episode/' + name + '.' + ext);
        if (old)
            fs.unlink(old);
        fs.writeFile(dir + '/' + name + '.' + ext, bytes, { canOwn: true });
    }

    // ---- Downloads kept in IndexedDB, one database per kind: "meta" holds
    // small records to list and evict by, "data" the files themselves, under
    // the same key. A file goes in as a Blob: Chromium refuses a record
    // whose own bytes are over 127 MiB (133169152), so a mod like SBX-JK
    // Continuum (305 MiB) wasn't kept, but it keeps a Blob's bytes beside the
    // record. Files saved before as bytes still read.

    function makeStore(dbName, maxBytes) {
        var dbPromise = null;

        function open() {
            if (dbPromise)
                return dbPromise;
            dbPromise = new Promise(function(resolve) {
                try {
                    var req = indexedDB.open(dbName, 1);
                    req.onupgradeneeded = function() {
                        req.result.createObjectStore('meta', { keyPath: 'key' });
                        req.result.createObjectStore('data');
                    };
                    req.onsuccess = function() { resolve(req.result); };
                    req.onerror = function() { resolve(null); };
                    req.onblocked = function() { resolve(null); };
                } catch (e) {
                    resolve(null);
                }
            });
            return dbPromise;
        }

        function request(req) {
            return new Promise(function(resolve, reject) {
                req.onsuccess = function() { resolve(req.result); };
                req.onerror = function() { reject(req.error); };
            });
        }

        function done(tx) {
            return new Promise(function(resolve, reject) {
                tx.oncomplete = function() { resolve(); };
                tx.onerror = tx.onabort = function() { reject(tx.error); };
            });
        }

        function key(game, name, sha) {
            return game + '/' + name.toLowerCase() + '/' + sha;
        }

        // A file's bytes as saved: an ArrayBuffer from a Blob, or the bytes.
        function bytesOf(data) {
            return typeof Blob !== 'undefined' && data instanceof Blob ? data.arrayBuffer() : data;
        }

        async function list(game) {
            var db = await open();
            if (!db)
                return [];
            var all = await request(db.transaction('meta').objectStore('meta').getAll());
            return all.filter(function(m) { return !game || m.game === game; });
        }

        // The record under k and its data, marked as just used.
        async function take(k) {
            var db = await open();
            if (!db)
                return null;
            var tx = db.transaction(['meta', 'data'], 'readwrite');
            var meta = await request(tx.objectStore('meta').get(k));
            var data = meta ? await request(tx.objectStore('data').get(k)) : null;
            if (meta && data) {
                meta.used = Date.now();
                tx.objectStore('meta').put(meta);
            }
            await done(tx);
            return meta && data ? { meta: meta, data: await bytesOf(data) } : null;
        }

        function get(game, name, sha) {
            return take(key(game, name, sha));
        }

        // By content alone, whatever name it was saved under.
        async function find(game, sha) {
            var metas = await list(game);
            for (var m of metas) {
                if (m.sha256 === sha)
                    return take(m.key);
            }
            return null;
        }

        async function read(k) {
            var db = await open();
            if (!db)
                return null;
            var data = await request(db.transaction('data').objectStore('data').get(k));
            return data ? bytesOf(data) : data;
        }

        // extra: more fields for the record, such as own (runJob).
        async function put(game, name, ext, sha, bytes, extra) {
            var db = await open();
            if (!db)
                return;
            var k = key(game, name, sha);
            var tx = db.transaction(['meta', 'data'], 'readwrite');
            tx.objectStore('data').put(new Blob([bytes]), k);
            var meta = { key: k, game: game, name: name, ext: ext, sha256: sha, size: bytes.length, used: Date.now() };
            for (var f in extra || {})
                meta[f] = extra[f];
            tx.objectStore('meta').put(meta);
            await done(tx);

            // Keep the store under its cap, dropping the least recently used.
            var metas = await list(null);
            metas.sort(function(a, b) { return b.used - a.used; });
            var total = 0;
            var drop = [];
            for (var m of metas) {
                total += m.size;
                if (total > maxBytes && m.key !== k)
                    drop.push(m.key);
            }
            if (drop.length) {
                tx = db.transaction(['meta', 'data'], 'readwrite');
                for (var d of drop) {
                    tx.objectStore('meta').delete(d);
                    tx.objectStore('data').delete(d);
                }
                await done(tx);
            }
        }

        return { list: list, get: get, find: find, read: read, put: put };
    }

    var store = makeStore('jkdf2mp-maps', MAX_STORED_BYTES);

    // Writes the maps stored for this game into episode/, the most recently
    // used version of each, unless the picked folder has one.
    async function installStoredMaps(root, game) {
        var metas = await store.list(game);
        metas.sort(function(a, b) { return b.used - a.used; });
        var seen = {};
        var names = [];
        for (var m of metas) {
            var lower = m.name.toLowerCase();
            if (seen[lower])
                continue;
            seen[lower] = true;
            if (!validEpisodeName(m.name) || !validExt(m.ext) || findPath(root, 'episode/' + m.name + '.' + m.ext))
                continue;
            var data = await store.read(m.key);
            if (!data)
                continue;
            install(root, m.name, m.ext, new Uint8Array(data));
            names.push(m.name);
        }
        return names;
    }

    // ---- What the joiner sees: a small panel over the game while a map
    // comes in, or with the reason it couldn't.

    var ui = (function() {
        var el = null, title, name, bar, detail, button;
        var onCancel = null;

        function make() {
            if (el || typeof document === 'undefined' || !document.body)
                return !!el;
            var style = document.createElement('style');
            style.textContent =
                '#jk-maps{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:20;' +
                'width:min(420px,calc(100vw - 32px));box-sizing:border-box;padding:12px 14px;' +
                'background:var(--teal-dark,#003333);color:var(--ink,#fff);border:2px solid var(--gold,#ffcc66);' +
                'font:14px/1.35 Arial,Helvetica,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.5)}' +
                '#jk-maps p{margin:0 0 6px}' +
                '#jk-maps .jk-maps-title{font:bold 15px Verdana,Geneva,sans-serif;color:var(--gold,#ffcc66)}' +
                '#jk-maps .jk-maps-name{font:bold 14px "Courier New",monospace;word-break:break-all}' +
                '#jk-maps progress{display:block;width:100%;height:12px;margin:2px 0 6px;accent-color:var(--gold,#ffcc66)}' +
                '#jk-maps .jk-maps-detail{color:var(--muted,#99cccc)}' +
                '#jk-maps.jk-maps-error .jk-maps-detail{color:var(--bad,#ffb199)}' +
                '#jk-maps button{font:bold 14px Verdana,Geneva,sans-serif;padding:3px 14px;cursor:pointer;' +
                'border:2px outset #ffe7a8;background:linear-gradient(#ffe7a8,var(--gold,#ffcc66) 55%,#e8a93a);color:#1a1a00}' +
                '#jk-maps button:active{border-style:inset}' +
                '#jk-maps button:focus-visible{outline:2px solid var(--gold,#ffcc66);outline-offset:2px}';
            document.head.appendChild(style);
            el = document.createElement('div');
            el.id = 'jk-maps';
            el.setAttribute('role', 'status');
            el.setAttribute('aria-live', 'polite');
            el.hidden = true;
            title = document.createElement('p');
            title.className = 'jk-maps-title';
            name = document.createElement('p');
            name.className = 'jk-maps-name';
            bar = document.createElement('progress');
            bar.max = 1;
            detail = document.createElement('p');
            detail.className = 'jk-maps-detail';
            button = document.createElement('button');
            button.type = 'button';
            button.addEventListener('click', function() {
                if (onCancel)
                    onCancel();
                else
                    hide();
            });
            el.append(title, name, bar, detail, button);
            document.body.appendChild(el);
            return true;
        }

        function mb(n) {
            return (n / 1048576).toFixed(n < 10485760 ? 1 : 0);
        }

        function what(kind) {
            return kind === KIND_MOD ? 'mod' : 'map';
        }

        function show(mapName, text, cancel, kind) {
            if (!make())
                return;
            el.className = '';
            el.hidden = false;
            title.textContent = "Getting the host's " + what(kind);
            name.textContent = mapName;
            bar.hidden = false;
            bar.removeAttribute('value');
            detail.textContent = text;
            button.textContent = 'Cancel';
            onCancel = cancel;
        }

        // rate: bytes a second, shown once there is one.
        function progress(done, total, via, rate) {
            if (!el || el.hidden)
                return;
            bar.value = total ? done / total : 0;
            detail.textContent = mb(done) + ' of ' + mb(total) + ' MB, ' +
                (rate ? (rate / 1048576).toFixed(1) + ' MB/s, ' : '') +
                (via === 'relay' ? 'through the lobby' : 'straight from the host');
        }

        function error(mapName, text, kind) {
            if (!make())
                return;
            el.className = 'jk-maps-error';
            el.hidden = false;
            title.textContent = "Couldn't get the " + what(kind);
            name.textContent = mapName;
            bar.hidden = true;
            detail.textContent = text;
            button.textContent = 'OK';
            onCancel = null;
            button.focus();
        }

        // Something the player should read that isn't a failure, such as the
        // game restarting with the host's mod.
        function notice(heading, itemName, text) {
            if (!make())
                return;
            el.className = '';
            el.hidden = false;
            title.textContent = heading;
            name.textContent = itemName;
            bar.hidden = true;
            detail.textContent = text;
            button.textContent = 'OK';
            onCancel = null;
        }

        function hide() {
            if (el)
                el.hidden = true;
            onCancel = null;
        }

        return { show: show, progress: progress, error: error, notice: notice, hide: hide };
    })();

    var MESSAGES = {
        'none': "The host's map isn't a single map file on their side, so it can't be sent.",
        'too-big': 'This map is over 1 GB, more than the browser can take in.',
        'memory': "This tab doesn't have the memory for it. Close other tabs, reload this page and try again.",
        'not-gob': "The host's map file isn't a GOB the game can read.",
        'retail-only': "The host's map is made only of original game files, so it isn't sent.",
        'too-many-files': 'This map has too many files to send.',
        'no-answer': "The host didn't answer. They may need to reload the page.",
        'stalled': 'The download stopped. The connection to the host may have dropped.',
        'host-left': 'The host left the game.',
        'lobby-lost': 'The connection to the lobby dropped.',
        'corrupt': "The map didn't arrive intact, so it wasn't installed.",
        'mismatch': "The map didn't arrive intact, so it wasn't installed.",
        'install': "The map couldn't be installed in this tab.",
        'bad-name': "The host's map name isn't one that can be saved.",
        'retail': "The host is running an original level, which isn't sent.",
        'other-map': 'The host is running a different map now.',
        'error': "The host couldn't get its map ready to send.",
        'cancelled': null
    };

    function messageFor(reason, ctx) {
        if (ctx.messageFor) {
            var own = ctx.messageFor(reason);
            if (own !== undefined)
                return own;
        }
        if (reason === 'retail-missing')
            return 'This game runs an original ' + gameOfEpisode(ctx.name) +
                   " level that isn't in the game folder you picked.";
        if (reason === 'other-game')
            return 'This game is for ' + (ctx.ext === 'goo' ? 'Jedi Knight' : 'Mysteries of the Sith') +
                   ', and the game folder you picked is ' + (ctx.ext === 'goo' ? 'Mysteries of the Sith.' : 'Jedi Knight.');
        if (reason === 'missing-retail')
            return 'This map uses original ' + (ctx.ext === 'goo' ? 'Mysteries of the Sith' : 'Jedi Knight') +
                   " files that weren't found in the game folder you picked.";
        if (reason === 'retail-changed')
            return 'Your game folder has other versions of original ' +
                   (ctx.ext === 'goo' ? 'Mysteries of the Sith files this map uses (the MotS Remastered pack ' +
                                        'changes some). ' : 'Jedi Knight files this map uses. ') +
                   'Ask the host to reload the page, then join again.';
        if (reason in MESSAGES)
            return MESSAGES[reason];
        return "The host's map couldn't be sent (" + reason + ').';
    }

    // ---- Frames.

    function frame(type, idTo, bodyLen, kind) {
        var buf = new ArrayBuffer(HEADER + bodyLen);
        var b = new Uint8Array(buf);
        var v = new DataView(buf);
        v.setUint32(0, idTo === 1 ? 0 : 1, true); // idFrom: the relay stamps a client's own
        v.setUint32(4, idTo, true);
        b.set(MAGIC, 8);
        b[12] = type;
        b[13] = VERSION;
        b[14] = kind || KIND_MAP;
        return { buf: buf, bytes: b, view: v };
    }

    function isFrame(data) {
        if (!(data instanceof ArrayBuffer) || data.byteLength < HEADER)
            return false;
        var b = new Uint8Array(data, 8, 4);
        return b[0] === MAGIC[0] && b[1] === MAGIC[1] && b[2] === MAGIC[2] && b[3] === MAGIC[3];
    }

    // The connection the frames go over: the lobby's (stdComm_WSRelay.c), or
    // while that one is picked the Imperial Network Protocol's
    // (stdComm_Imperial.c), which has the same mapSend and mapDirect.
    function link() {
        var imp = Module.jkImperial;
        return imp && imp.active ? imp : Module.jkNet;
    }

    function send(id, f, via) {
        var net = link();
        return net && net.mapSend ? net.mapSend(id, f.buf, via) : null;
    }

    function idOf(sha) {
        var out = new Uint8Array(8);
        for (var i = 0; i < 8; i++)
            out[i] = parseInt(sha.substr(i * 2, 2), 16);
        return out;
    }

    function sameId(a, b) {
        for (var i = 0; i < 8; i++)
            if (a[i] !== b[i]) return false;
        return true;
    }

    // ---- Host: gets each thing it offers (its map, its mod) ready once when
    // it starts hosting, then answers whoever asks.

    var offers = {}; // kind -> { info, stream, id, waiting, blocks }

    // prepare() resolves to { info, stream }: the INFO joiners get, and with
    // status 'ok' the stream their chunks and blocks are cut from (bytes, or
    // pieces()).
    function offer(kind, prepare) {
        var h = offers[kind] = { info: null, stream: null, id: null, waiting: [], blocks: new Map() };
        (async function() {
            var r;
            try {
                r = await prepare();
            } catch (e) {
                console.warn('OpenJKDF2: could not get the ' + (kind === KIND_MOD ? 'mod' : 'map') +
                             ' ready for joiners: ' + e);
                r = { info: { status: 'error' } };
            }
            // Gone unless some kind still offers it (next.host's offer goes on
            // as the map once the host is in that level, host()).
            if (!Object.keys(offers).some(function(k) { return offers[k] === h; }))
                return;
            h.info = r.info;
            if (r.info.status === 'ok' && r.stream) {
                h.stream = r.stream.views ? r.stream : pieces([r.stream]);
                h.id = idOf(r.info.sha256);
                h.info.z = BLOCK_BYTES;
            }
            for (var w of h.waiting)
                sendInfo(w.kind === undefined ? kind : w.kind, w.id, w.via);
            h.waiting = [];
        })();
    }

    function withdraw(kind) {
        delete offers[kind];
        forget(undefined, false, kind);
    }

    function host(name, ext) {
        // The playlist's next level, got ready as the last one ended: the
        // same offer, not hashed again, and players still getting it carry on.
        var n = offers[KIND_NEXT];
        if (n && n.name === String(name).toLowerCase() && n.ext === ext) {
            offers[KIND_MAP] = n;
            return;
        }
        offer(KIND_MAP, prepareMap(name, ext));
        offers[KIND_MAP].name = String(name).toLowerCase();
        offers[KIND_MAP].ext = ext;
    }

    // The next level of the host's playlist (src/Main/jkPlaylist.c), for the
    // players who don't have it, and who's still getting it.
    var nextStatus = {}; // player id -> { s, p }
    var nextName = '';
    function hostNext(name, ext) {
        nextStatus = {};
        nextName = String(name).toLowerCase();
        var m = offers[KIND_MAP];
        if (m && m.name === nextName && m.ext === ext) {
            offers[KIND_NEXT] = m;
            return;
        }
        offer(KIND_NEXT, prepareMap(name, ext));
        offers[KIND_NEXT].name = nextName;
        offers[KIND_NEXT].ext = ext;
    }

    // Of these players (ids), how many are still getting the next level, and
    // the least far along of them (-1 when none has said). One that hasn't
    // said anything yet is still getting it, as far as the host knows.
    function waitingFor(ids) {
        var count = 0, least = -1;
        for (var id of ids) {
            var st = nextStatus[id];
            if (st && st.s !== STATE_BUSY)
                continue;
            count++;
            if (st && st.p >= 0 && (least < 0 || st.p < least))
                least = st.p;
        }
        return { count: count, least: least };
    }

    function prepareMap(name, ext) {
        return async function() {
            var info = { status: 'none', name: name, ext: ext };
            var stream = null;
            try {
                var root = gameRoot();
                var path = validEpisodeName(name) && validExt(ext) ? findPath(root, 'episode/' + name + '.' + ext) : null;
                if (isRetailEpisode(name)) {
                    info.status = 'retail';
                } else if (path && isFile(path)) {
                    if (FS().stat(path).size > MAX_MAP_BYTES) {
                        info.status = 'too-big';
                    } else {
                        var gob = fileBytes(path);
                        var plan = await planShare(gob, retailSources(root, ext));
                        if (plan.ok) {
                            info = { status: 'ok', name: name, ext: ext, size: gob.length,
                                     sha256: await sha256(gob), streamSize: plan.stream.length,
                                     refsBytes: plan.refsBytes };
                            // For a joiner who has other versions of the
                            // original files left out (ownVersions).
                            if (plan.refs && plan.stream.length <= MAX_STREAM_HASH_BYTES)
                                info.streamSha256 = await sha256(plan.stream.bytes());
                            stream = plan.stream;
                            console.log('OpenJKDF2: ready to send map ' + name + '.' + ext + ' to joiners (' +
                                        plan.refs + ' original files left out, ' + plan.stream.length + ' of ' +
                                        gob.length + ' bytes to send)');
                        } else {
                            info.status = plan.reason;
                        }
                    }
                }
            } catch (e) {
                console.warn('OpenJKDF2: could not prepare map ' + name + ' for joiners: ' + e);
                info = { status: 'error', name: name, ext: ext };
            }
            return { info: info, stream: stream };
        };
    }

    function unhost() {
        withdraw(KIND_MAP);
        withdraw(KIND_NEXT);
        nextStatus = {};
        nextName = '';
    }

    function sendInfo(kind, id, via) {
        var json = new TextEncoder().encode(JSON.stringify(offers[kind].info));
        var f = frame(T_INFO, id, json.length, kind);
        f.bytes.set(json, HEADER);
        send(id, f, via);
    }

    // Chunks and blocks are asked for by the file's id, whichever kind it is.
    // kind: the one the joiner asks as, whose frames it takes the answer in,
    // when that offers it (the playlist's next level is offered as the map
    // too once the host is in it, host()).
    function offerFor(want, kind) {
        var o = offers[kind];
        if (o && o.stream && sameId(want, o.id))
            return kind;
        for (var key in offers) {
            if (offers[key].stream && sameId(want, offers[key].id))
                return Number(key);
        }
        return null;
    }

    // ---- Squeezing blocks with deflate: in workers, since a 1 MB block takes
    // about 30 ms and a host in a match would miss frames, or here where a
    // worker can't be made.

    var squeezer = (function() {
        var SOURCE = 'onmessage=function(e){var d=e.data;' +
            'new Response(new Blob([d.bytes]).stream().pipeThrough(new CompressionStream("deflate-raw"))).arrayBuffer()' +
            '.then(function(z){postMessage({n:d.n,z:z},[z]);},function(){postMessage({n:d.n,z:null});});};';
        var workers = null;
        var jobs = {};
        var seq = 0;

        function can() {
            return typeof CompressionStream !== 'undefined';
        }

        function here(bytes) {
            return new Response(new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate-raw')))
                .arrayBuffer().then(function(z) { return new Uint8Array(z); }, function() { return null; });
        }

        // A worker that fails gives up on them all: what it had resolves to
        // null (sent as is), and the rest is squeezed here.
        function broke() {
            for (var w of workers)
                w.terminate();
            workers = [];
            for (var n in jobs)
                jobs[n].resolve(null);
            jobs = {};
        }

        function start() {
            if (workers)
                return;
            workers = [];
            try {
                if (typeof Worker === 'undefined' || typeof URL === 'undefined' || !URL.createObjectURL)
                    return;
                var url = URL.createObjectURL(new Blob([SOURCE], { type: 'text/javascript' }));
                var cores = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency) || 2;
                for (var i = 0; i < Math.max(1, Math.min(4, cores - 1)); i++) {
                    var w = new Worker(url);
                    w.busy = 0;
                    w.onmessage = function(ev) {
                        var job = jobs[ev.data.n];
                        if (!job)
                            return;
                        delete jobs[ev.data.n];
                        job.worker.busy--;
                        job.resolve(ev.data.z ? new Uint8Array(ev.data.z) : null);
                    };
                    w.onerror = broke;
                    workers.push(w);
                }
            } catch (e) {
                workers = [];
            }
        }

        // bytes is the worker's to keep: a copy of its own.
        function squeeze(bytes) {
            start();
            if (!workers.length)
                return here(bytes);
            return new Promise(function(resolve) {
                var w = workers.reduce(function(a, b) { return b.busy < a.busy ? b : a; });
                var n = ++seq;
                jobs[n] = { resolve: resolve, worker: w };
                w.busy++;
                w.postMessage({ n: n, bytes: bytes }, [bytes.buffer]);
            });
        }

        return { can: can, squeeze: squeeze };
    })();

    // Block b of what o offers, as sent to a joiner that can unsqueeze what
    // accept says: { codec, bytes }. Squeezed blocks are kept for the next
    // joiner, and so is knowing that one doesn't get smaller.
    function block(o, b, accept) {
        var at = b * BLOCK_BYTES;
        var n = Math.min(BLOCK_BYTES, o.stream.length - at);
        if (!(accept & CODEC_DEFLATE) || !squeezer.can())
            return Promise.resolve({ codec: CODEC_STORED, bytes: o.stream.read(at, n) });
        var p = o.blocks.get(b);
        if (!p) {
            p = squeezer.squeeze(o.stream.read(at, n).slice()).then(function(z) {
                return z && z.length < n ? z : null;
            });
            o.blocks.set(b, p);
        }
        return p.then(function(z) {
            return z ? { codec: CODEC_DEFLATE, bytes: z } : { codec: CODEC_STORED, bytes: o.stream.read(at, n) };
        });
    }

    // ---- Watching a match (spectator mode): what the host offers, for the
    // games watching its match from inside the game that don't have it
    // (mods.js, for its mod). One of them asks the match's feed
    // (jkdf2mp-bb-server's src/feed.js), the feed asks the host's game ("mod
    // <fp>" on its feed socket, stdComm_WSRelay.c), and it puts it there
    // (feedUp): its INFO with parts (how many blocks) at <feed>/mod/<fp>/info,
    // then each block b at <feed>/mod/<fp>/<b>, a byte for its codec and the
    // block as a joiner gets it, squeezed where that makes it smaller. The
    // original game files are left out as for a joiner. The game watching
    // gets them from there (feedGet).
    //
    // The host is playing on the same upload, so blocks go one at a time and
    // no faster than FEED_UP_RATE, and one that takes longer than that (the
    // upload is slower) is followed by a pause half as long, so the game's
    // own packets aren't left waiting behind the mod. Once for each feed,
    // unless that failed or a game asks again FEED_UP_AGAIN_MS later.
    var FEED_UP_RATE = 256 * 1024;
    var FEED_UP_TRIES = 5;
    var FEED_UP_READY_MS = 120000;
    var FEED_UP_AGAIN_MS = 60000;
    var feedUps = {}; // feed address + fp -> { running, ok, at }

    function delay(ms) {
        return new Promise(function(resolve) { setTimeout(resolve, ms); });
    }

    // feedUrl: the feed's https address with the host's token (?up=), as
    // the host's game sends to it. alive(): whether that's still its feed.
    function feedUp(kind, feedUrl, fp, alive) {
        var q = String(feedUrl).indexOf('?');
        if (q < 0 || !/^[0-9a-f]{64}$/.test(fp) || !offers[kind])
            return false;
        var key = feedUrl + ' ' + fp;
        var u = feedUps[key];
        if (u && (u.running || (u.ok && Date.now() - u.at < FEED_UP_AGAIN_MS)))
            return false;
        if (Object.keys(feedUps).length > 16)
            feedUps = {};
        u = feedUps[key] = { running: true, ok: false, at: Date.now() };
        var base = feedUrl.substring(0, q) + '/mod/' + fp + '/', query = feedUrl.substring(q);
        runFeedUp(kind, base, query, fp, alive || function() { return true; }).then(function(r) {
            u.ok = r.ok;
            if (r.ok)
                console.log('OpenJKDF2: sent ' + r.what + ' to the match\'s feed for a game watching (' + r.parts +
                            ' blocks, ' + Math.round(r.bytes / 1024) + ' KiB in ' + Math.round(r.ms / 1000) + ' s)');
            else
                console.log('OpenJKDF2: did not send ' + (kind === KIND_MOD ? 'the mod' : 'the map') +
                            ' to the match\'s feed: ' + r.why);
        }, function(e) {
            console.warn('OpenJKDF2: could not send to the match\'s feed: ' + e);
        }).finally(function() {
            u.running = false;
            u.at = Date.now();
        });
        return true;
    }

    async function runFeedUp(kind, base, query, fp, alive) {
        var o, waited = 0;
        for (;;) {
            o = offers[kind];
            if (!o || !alive())
                return { ok: false, why: 'gone' };
            if (o.info)
                break;
            if (waited >= FEED_UP_READY_MS)
                return { ok: false, why: 'not ready' };
            await delay(500);
            waited += 500;
        }
        var info, parts = 0;
        if (o.info.status === 'ok' && o.stream) {
            if (o.info.sha256 !== fp)
                return { ok: false, why: 'another one asked for' };
            parts = Math.ceil(o.stream.length / BLOCK_BYTES);
            info = Object.assign({}, o.info, { z: BLOCK_BYTES, parts: parts });
        } else {
            // Why it can't be sent, for the game watching to say.
            info = { status: o.info.status === 'ok' ? 'error' : o.info.status || 'error', name: o.info.name, ext: o.info.ext };
        }
        var began = Date.now(), sent = 0;
        async function put(part, body) {
            for (var t = 0; ; t++) {
                var status = 0;
                try {
                    var r = await fetch(base + part + query, { method: 'PUT', body: body,
                                                               headers: { 'Content-Type': 'application/octet-stream' } });
                    status = r.status;
                    if (r.ok)
                        return;
                } catch (e) {}
                // The feed ended, isn't this game's, or won't take it.
                if (status === 400 || status === 403 || status === 404 || status === 413)
                    throw fail('refused (' + status + ')');
                if (t + 1 >= FEED_UP_TRIES || offers[kind] !== o || !alive())
                    throw fail(status ? 'failed (' + status + ')' : 'failed');
                await delay(2000 * Math.pow(2, t));
            }
        }
        try {
            var json = new TextEncoder().encode(JSON.stringify(info));
            await put('info', json);
            sent += json.length;
            for (var b = 0; b < parts; b++) {
                if (offers[kind] !== o || !alive())
                    return { ok: false, why: 'gone' };
                var blk = await block(o, b, CODEC_DEFLATE);
                var body = new Uint8Array(1 + blk.bytes.length);
                body[0] = blk.codec;
                body.set(blk.bytes, 1);
                var t0 = Date.now();
                await put(String(b), body);
                var took = Date.now() - t0, budget = body.length * 1000 / FEED_UP_RATE;
                sent += body.length;
                await delay(took > budget ? took / 2 : budget - took);
            }
        } catch (e) {
            return { ok: false, why: e.reason || String(e) };
        }
        return { ok: info.status === 'ok', why: info.status, what: (kind === KIND_MOD ? 'mod ' : 'map ') + (info.name || ''),
                 parts: parts, bytes: sent, ms: Date.now() - began };
    }

    // A game watching: the host's offer from the match's feed, src.base its
    // <feed>/mod/<fp>/ (https) and src.ask() what asks the feed for it. The
    // INFO is looked for every FEED_POLL_MS, asked for when it isn't there
    // and every FEED_ASK_MS while it doesn't come, up to FEED_WAIT_MS;
    // check(info) throws if it isn't the one wanted. Then the blocks,
    // FEED_GETS at a time: one not there yet (the host is still sending) is
    // looked for again, up to FEED_STALL_MS with none coming, asking again
    // as above. onProgress(done, total) says how far along it is (total 0
    // while asking). Resolves to the file, checked against the host's
    // SHA-256.
    var FEED_POLL_MS = 2000, FEED_ASK_MS = 20000, FEED_WAIT_MS = 90000, FEED_STALL_MS = 60000, FEED_GETS = 4;

    async function feedGet(j, src, check, onProgress) {
        var stop = typeof AbortController !== 'undefined' ? new AbortController() : null;
        var wake = null;
        j.cancel = function(e) {
            if (stop)
                stop.abort();
            if (wake)
                wake(e || fail('cancelled'));
        };
        function pause(ms) {
            return new Promise(function(resolve, reject) {
                if (j.done)
                    return reject(fail('cancelled'));
                wake = reject;
                j.timers.push(setTimeout(function() {
                    wake = null;
                    resolve();
                }, ms));
            });
        }
        // A part's bytes, or null while it isn't there.
        async function get(part) {
            var r;
            try {
                r = await fetch(src.base + part, { cache: 'no-store', signal: stop ? stop.signal : undefined });
            } catch (e) {
                if (j.done)
                    throw fail('cancelled');
                return null;
            }
            if (j.done)
                throw fail('cancelled');
            if (!r.ok)
                return null;
            return new Uint8Array(await r.arrayBuffer());
        }
        onProgress = onProgress || function() {};
        var began = Date.now(), asked = 0, info = null;
        onProgress(0, 0);
        for (;;) {
            var raw = await get('info');
            if (raw) {
                try { info = JSON.parse(new TextDecoder().decode(raw)); } catch (e) {}
                if (!info || typeof info !== 'object')
                    throw fail('corrupt');
                break;
            }
            var now = Date.now();
            if (now - began > FEED_WAIT_MS)
                throw fail('host-silent');
            if (now - asked >= FEED_ASK_MS) {
                asked = now;
                src.ask();
            }
            await pause(FEED_POLL_MS);
        }
        if (info.status !== 'ok')
            throw fail(typeof info.status === 'string' && /^[a-z-]{1,32}$/.test(info.status) ? info.status : 'error');
        check(info);
        var parts = Math.ceil(info.streamSize / BLOCK_BYTES);
        if (info.z !== BLOCK_BYTES || info.parts !== parts)
            throw fail('corrupt');
        var rb = rebuilder(info, retailSources(gameRoot(), info.ext));
        var next = 0, done = 0, bytes = 0, lastNew = Date.now();
        onProgress(0, info.streamSize);

        async function one(b) {
            for (;;) {
                var body = await get(String(b));
                if (body) {
                    var size = Math.min(BLOCK_BYTES, info.streamSize - b * BLOCK_BYTES);
                    var data = body.subarray(1);
                    if (body[0] === CODEC_DEFLATE)
                        data = await inflate(data, size);
                    else if (body[0] !== CODEC_STORED || data.length !== size)
                        throw fail('corrupt');
                    if (j.done)
                        throw fail('cancelled');
                    rb.put(b * BLOCK_BYTES, data);
                    done++;
                    bytes += size;
                    lastNew = Date.now();
                    onProgress(bytes, info.streamSize);
                    return;
                }
                var now = Date.now();
                if (now - lastNew > FEED_STALL_MS)
                    throw fail('host-stalled');
                // Not sent yet, or the host stopped: ask again once in a while.
                if (now - lastNew >= FEED_ASK_MS && now - asked >= FEED_ASK_MS) {
                    asked = now;
                    src.ask();
                }
                await pause(FEED_POLL_MS);
            }
        }
        async function lane() {
            while (next < parts)
                await one(next++);
        }
        var lanes = [];
        for (var i = 0; i < Math.min(FEED_GETS, parts); i++)
            lanes.push(lane());
        await Promise.all(lanes);
        var result = await rb.finish();
        if (!result.ok)
            throw fail(result.reason);
        return result.bytes;
    }

    // ---- Host: what joiners ask for goes out paced.
    //
    // Parts wait here and go one at a time from each block (or a joiner's
    // chunks) asked for in turn, while the way they go has little waiting in
    // it (link().mapBacklog). Through the lobby, and on the Imperial Network
    // Protocol, that way is the socket that also carries the host's game
    // packets; on a direct link it's the same upload. So in a match (someone
    // else has been heard from lately, link().mapInMatch) they also go no
    // faster than a rate that halves when the connection shows a queue
    // building (link().mapCongested) and grows while it says it doesn't. What
    // waits in the browser is all a page can see, not what waits in the
    // computer or the router, so the rate starts low and only grows on a
    // sign that sees those. Until the first queue it grows by a quarter each
    // time (slow start), so a fast upload is soon used; from then on, a step
    // at a time. A part asked for again while it waits isn't queued twice:
    // it goes the way of the newer request.

    // What may wait on the way a part goes before another goes: on the
    // lobby's or Imperial's socket in a match, outside one, and on a map
    // channel outside a match and in one. Outside a match nothing else holds
    // a part back, so a match that starts while a download goes on waits for
    // what the computer and the router already hold to leave: some seconds
    // on a slow upload (pacing-test.mjs), as the rate stays at its least.
    // In a match a map channel may also have what one pump may send at the
    // rate (up.burst) waiting: what waits in its buffer holds up no one
    // else's packets, which go on connections of their own, and at 2-3
    // frames a second 64 KiB a pump held a fast upload to a few hundred KB/s
    // whatever the rate, where the computer and the router hold little of
    // the channel's (pacing-test.mjs). But no more than the channel took in
    // PACE_PART_MS / 2 lately (wayOf): a joiner's tab or downlink slow to take
    // the map holds it in the host's buffer, which nothing halves the rate
    // for, and a block asked for then waited behind 1-2 MB of the ones
    // before, more than CHUNK_RESEND_MS, so it was asked for and sent again.
    var PACE_LOW_SOCKET_MATCH = 16 * 1024;
    var PACE_LOW_SOCKET = 256 * 1024;
    var PACE_LOW_CHANNEL = 1024 * 1024;
    var PACE_LOW_CHANNEL_MATCH = 64 * 1024;
    var PACE_MAX_QUEUED = 16 * 1024 * 1024;  // waiting for one joiner
    // Bytes a second in a match: where it starts, at most, and what it grows
    // by each time the link says no queue is building: times PACE_GROW until
    // it first says there is one, PACE_STEP for each PACE_EVERY_MS after.
    var PACE_START = 48000;
    var PACE_FLOOR = 24000;
    var PACE_MAX = 2000000;
    var PACE_STEP = 16000;
    // Faster overshoots a slower upload by more: at half again, game packets
    // waited up to 720 ms in pacing-test.mjs's model, against 450 ms.
    var PACE_GROW = 1.25;
    var PACE_EVERY_MS = 250;
    // A link that says so less often grows by steps for the time since the
    // rate last changed, up to PACE_SAID_MS of it, but in slow start by
    // PACE_GROW each time all the same: nothing says how the new rate does
    // until the next answer, and a queue it starts builds until then. The
    // Imperial relay server answers every 2 s at most, so there a rate that
    // doubled at each answer went from just under the upload to twice it,
    // and game packets waited 1-2 s on 3.5-4.5 Mbit/s uploads in
    // pacing-test.mjs's model (half again: up to 1.1 s at 6 Mbit/s); now
    // 0.5 s at most. A fast upload then takes about 28 s to reach 1 MiB/s,
    // all the Imperial pump sends (an 8 MB map 22 s, not 13).
    var PACE_SAID_MS = 1000;
    // Joiners ask for a block again when no part of it came for
    // CHUNK_RESEND_MS, and give up after STALL_MS without any: every block
    // being sent gets a part at least twice that often, however low the rate.
    var PACE_PART_MS = CHUNK_RESEND_MS / 2;
    var PACE_TICK_MS = 10;
    // A rate learned in one transfer is kept for the next unless it's long after.
    var PACE_FORGET_MS = 30000;
    // The network log gets a line on a paced upload this often, and sooner
    // (no sooner than PACE_NOTE_SOON_MS after the last) when the rate is
    // PACE_NOTE_MOVE times or a PACE_NOTE_MOVE-th what the last line said
    // and out of the range it went over before that line. The rate halves
    // at each queue and grows back: at twice or half a line came every 2-3 s
    // on a slow upload, and a long one's lines pushed the start of the
    // session out of the 1000 the log keeps. Each line says the range.
    var PACE_NOTE_MS = 10000;
    var PACE_NOTE_SOON_MS = 2000;
    var PACE_NOTE_MOVE = 4;

    var up = {
        groups: new Map(), // 'to kind b<block>' or 'to kind c<size>' -> group
        turn: [],          // their keys, in turn
        next: 0,
        queued: {},        // joiner -> bytes waiting for them
        rate: PACE_START,
        slow: true,        // no queue seen since the rate started over
        tokens: 0,
        burst: 0,          // the most tokens may come to
        at: 0,             // when tokens were last added
        sampledAt: 0,
        changedAt: 0,      // when the rate last grew or halved
        paced: false,      // the last pump was in a match
        // The most part bytes a turn round the groups took lately, and when.
        need: 0, needAt: 0,
        sentAt: 0,
        // The longest wait between pumps lately: in a hidden tab timers run
        // once a second at most, so a pump may have to send a second's worth.
        pumpedAt: 0, gap: 0, gapNow: 0, gapSince: 0,
        timer: null,
        pumping: false,
        // Something went in this task: what a link says is waiting includes
        // it until the browser takes it, so the link isn't asked about a
        // queue until the next task.
        dirty: false,
        sent: 0,
        // For the network log (noteRate): the looks at the link since its
        // last line that said a queue, none, and no telling, and why the last
        // of each said so; the rate it last said, and when.
        // The least and the most rate since that line, and before it (from
        // the line before).
        looks: [0, 0, 0], whys: ['', '', ''], notedRate: 0, notedAt: 0, notedLow: 0, notedHigh: 0,
        bandLow: 0, bandHigh: 0,
        // Nothing waited since the last line: the next upload may be another.
        emptied: false,
        // The map channels parts went on (wayOf), by joiner and way.
        ways: {}
    };

    function partBytes(g, p) {
        return g.chunk ? Math.min(g.chunk, g.o.stream.length - p * g.chunk) : Math.min(g.cut, g.bytes.length - p);
    }

    function addGroup(key, g) {
        g.key = key;
        g.parts = [];
        g.has = new Set();
        up.groups.set(key, g);
        up.turn.push(key);
        return g;
    }

    function removeGroup(g) {
        if (up.groups.get(g.key) !== g)
            return;
        up.groups.delete(g.key);
        if (!up.groups.size)
            up.emptied = true;
        var i = up.turn.indexOf(g.key);
        up.turn.splice(i, 1);
        if (i < up.next)
            up.next--;
        for (var p of g.parts)
            up.queued[g.to] -= partBytes(g, p);
    }

    // Puts parts p of g in the queue, unless they're there already or the
    // joiner has too much waiting (they ask again for what doesn't come).
    function queueParts(g, ps) {
        for (var p of ps) {
            if (g.has.has(p))
                continue;
            var n = partBytes(g, p);
            if ((up.queued[g.to] || 0) + n > PACE_MAX_QUEUED)
                break;
            up.queued[g.to] = (up.queued[g.to] || 0) + n;
            g.parts.push(p);
            g.has.add(p);
        }
        // A block's parts go in order, whatever was asked for again.
        if (!g.chunk)
            g.parts.sort(function(x, y) { return x - y; });
        if (!g.parts.length)
            removeGroup(g);
        pump();
    }

    function queueBlock(k, o, b, to, via, part, accept) {
        block(o, b, accept).then(function(r) {
            if (offers[k] !== o)
                return;
            var net = link();
            // A joiner takes parts of any whole number of UNITs, so on the
            // lobby's connection they're cut at that: none goes over the
            // lobby's 64 KiB, and game packets never wait behind a big one.
            // On the Imperial Network Protocol, desktop joiners get the size
            // they asked for. The least rate there is then a 64 KiB part of
            // each block every PACE_PART_MS, about 79 KB/s for each joiner
            // with three out: more than a 1 Mbit/s upload once two download
            // at once, and the others' game packets then wait seconds.
            var cut = net && net === Module.jkImperial ? part : UNIT;
            var key = to + ' ' + k + ' b' + b;
            var g = up.groups.get(key);
            if (g && (g.o !== o || g.codec !== r.codec || g.bytes.length !== r.bytes.length || g.cut !== cut)) {
                removeGroup(g);
                g = null;
            }
            if (!g)
                g = addGroup(key, { to: to, kind: k, o: o, b: b, cut: cut, codec: r.codec, bytes: r.bytes, chunk: 0 });
            g.via = via;
            var ps = [];
            for (var at = 0; at < r.bytes.length; at += cut)
                ps.push(at);
            queueParts(g, ps);
        }, function(e) {
            console.warn('OpenJKDF2: could not send block ' + b + ': ' + e);
        });
    }

    function queueChunks(k, o, to, via, size, first, count) {
        var key = to + ' ' + k + ' c' + size;
        var g = up.groups.get(key);
        if (g && g.o !== o) {
            removeGroup(g);
            g = null;
        }
        if (!g)
            g = addGroup(key, { to: to, kind: k, o: o, cut: size, chunk: size });
        g.via = via;
        var ps = [];
        for (var i = first; i < first + count && i * size < o.stream.length; i++)
            ps.push(i);
        queueParts(g, ps);
    }

    function partFrame(g, p) {
        var n = partBytes(g, p);
        if (g.chunk) {
            var f = frame(T_CHUNK, g.to, 12 + n, g.kind);
            f.bytes.set(g.o.id, HEADER);
            f.view.setUint32(HEADER + 8, p, true);
            f.bytes.set(g.o.stream.read(p * g.chunk, n), HEADER + 12);
            return f;
        }
        var f = frame(T_BLOCK, g.to, BLOCK_HEADER + n, g.kind);
        f.bytes.set(g.o.id, HEADER);
        f.view.setUint32(HEADER + 8, g.b, true);
        f.view.setUint32(HEADER + 12, g.bytes.length, true);
        f.view.setUint32(HEADER + 16, p, true);
        f.bytes[HEADER + 20] = g.codec;
        f.bytes.set(g.bytes.subarray(p, p + n), HEADER + BLOCK_HEADER);
        return f;
    }

    // Whether g's parts go on the socket that carries the game's packets.
    function onSocket(net, g) {
        return net === Module.jkImperial || g.via === 'relay' ||
               (g.via === 'direct' && !(net && net.mapDirect && net.mapDirect(g.to)));
    }

    // A map channel g's parts go on, and how fast it took them lately (bytes
    // a second): what waited on it after the last pump that sent on it, less
    // what waits now, once a pump. While something waited on it all along,
    // that's how fast the joiner takes the map; one that emptied may take it
    // faster, and keeps the most it was seen to.
    function wayOf(net, g, now) {
        var key = g.to + ' ' + g.via, w = up.ways[key];
        if (!w)
            w = up.ways[key] = { to: g.to, via: g.via, left: 0, at: 0, takes: 0, seen: 0 };
        if (w.seen !== now) {
            var b = net.mapBacklog(g.to, g.via);
            if (w.at && now > w.at) {
                var took = Math.max(0, w.left - b) * 1000 / (now - w.at);
                w.takes = b > 0 ? took : Math.max(took, w.takes);
            }
            w.seen = now;
        }
        return w;
    }

    function hasRoom(net, g, inMatch, now) {
        if (!net || !net.mapBacklog)
            return true;
        var low;
        if (onSocket(net, g)) {
            low = inMatch ? PACE_LOW_SOCKET_MATCH : PACE_LOW_SOCKET;
        } else {
            var w = wayOf(net, g, now);
            low = inMatch ? Math.max(PACE_LOW_CHANNEL_MATCH, Math.min(up.burst, w.takes * PACE_PART_MS / 2000)) : PACE_LOW_CHANNEL;
        }
        return net.mapBacklog(g.to, g.via) < low;
    }

    // Sends what may go now. The network code calls it each frame and as
    // packets come in, as well as the timer here, which a hidden tab slows.
    function pump() {
        if (!up.groups.size) {
            // Idle: the next transfer starts with no burst saved up, nor
            // what its channels took.
            up.pumpedAt = 0;
            up.ways = {};
            return;
        }
        if (up.pumping)
            return;
        up.pumping = true;
        try {
            pumpNow();
        } finally {
            up.pumping = false;
        }
        if (up.groups.size && !up.timer)
            up.timer = setTimeout(function() { up.timer = null; pump(); }, PACE_TICK_MS);
    }

    function pumpNow() {
        var now = Date.now();
        var net = link();
        if (!up.pumpedAt) {
            up.gap = up.gapNow = 0;
            up.gapSince = up.at = now;
            up.tokens = Math.min(up.tokens, 1);
            up.paced = false;
        } else {
            if (now - up.gapSince > 2000) {
                up.gap = up.gapNow;
                up.gapNow = 0;
                up.gapSince = now;
            }
            up.gapNow = Math.max(up.gapNow, Math.min(1000, now - up.pumpedAt));
        }
        up.pumpedAt = now;
        var inMatch = false, lobby = false, need = 0;
        up.groups.forEach(function(g) {
            if (net && net.mapInMatch && net.mapInMatch(g.to))
                inMatch = true;
            if (onSocket(net, g))
                lobby = true;
            need += g.cut;
        });
        // Groups that finish leave the turn they finished in no shorter for
        // the others still in it: the rate doesn't fall for that until a
        // whole turn has gone.
        if (need >= up.need || now - up.needAt > PACE_PART_MS) {
            up.need = need;
            up.needAt = now;
        }
        if (inMatch) {
            // Every block (or joiner's chunks) being sent gets a part each
            // PACE_PART_MS, the way they take turns.
            var least = Math.max(PACE_FLOOR, up.need * 1000 / PACE_PART_MS);
            if (up.sentAt && now - up.sentAt > PACE_FORGET_MS) {
                up.rate = PACE_START;
                up.slow = true;
            }
            // The time it grows for counts from when it's paced again.
            if (!up.paced)
                up.changedAt = now;
            if (now - up.sampledAt >= PACE_EVERY_MS && !up.dirty && net && net.mapCongested) {
                var c = net.mapCongested(lobby);
                up.sampledAt = now;
                var said = c === true ? 0 : c === false ? 1 : 2;
                up.looks[said]++;
                up.whys[said] = net.mapWhy || '';
                if (c === true) {
                    up.rate /= 2;
                    up.slow = false;
                    up.changedAt = now;
                } else if (c === false) {
                    var k = Math.max(1, Math.floor(Math.min(PACE_SAID_MS, now - up.changedAt) / PACE_EVERY_MS));
                    up.rate = up.slow ? up.rate * PACE_GROW : up.rate + PACE_STEP * k;
                    up.changedAt = now;
                }
            }
            up.rate = Math.min(PACE_MAX, Math.max(least, up.rate));
            up.burst = up.rate * Math.max(50, up.gap, up.gapNow) / 1000;
            up.tokens = Math.min(up.burst, up.tokens + Math.max(0, now - up.at) * up.rate / 1000);
        }
        noteRate(net, now, inMatch);
        up.paced = inMatch;
        up.at = now;
        // Round the blocks, a part from each that has room on its way.
        for (var idle = 0; up.groups.size && idle < up.turn.length; ) {
            if (inMatch && up.tokens <= 0)
                break;
            if (up.next >= up.turn.length)
                up.next = 0;
            var g = up.groups.get(up.turn[up.next]);
            if (offers[g.kind] !== g.o) {
                removeGroup(g);
                continue;
            }
            if (!hasRoom(net, g, inMatch, now)) {
                up.next++;
                idle++;
                continue;
            }
            var p = g.parts.shift();
            g.has.delete(p);
            var n = partBytes(g, p);
            up.queued[g.to] -= n;
            var f = partFrame(g, p);
            var went = send(g.to, f, g.via);
            if (!up.dirty) {
                up.dirty = true;
                Promise.resolve().then(function() { up.dirty = false; });
            }
            if (!went) {
                // Its way is gone: the joiner asks again on another.
                removeGroup(g);
                continue;
            }
            idle = 0;
            up.sent += f.buf.byteLength;
            up.sentAt = now;
            if (inMatch)
                up.tokens -= f.buf.byteLength;
            if (g.parts.length)
                up.next++;
            else
                removeGroup(g);
        }
        // What waits now on each channel looked at, for what it takes by the
        // next pump (wayOf).
        for (var key in up.ways) {
            var w = up.ways[key];
            if (w.seen === now) {
                w.left = net.mapBacklog(w.to, w.via);
                w.at = now;
            }
        }
    }

    // A line in the network log (Module.jkNet.note) on a paced upload, so a
    // player's saved log shows what the pacing did: as it starts, every
    // PACE_NOTE_MS, sooner when the rate moved PACE_NOTE_MOVE times since the
    // last line and out of the range before it, and when an upload that was
    // paced goes on unpaced (not one that starts PACE_NOTE_MS or more after
    // the last finished, which starts anew). The rate, the least and the
    // most since the last line, what the looks at the link since then said
    // and why (numbers only: round trips, what waits), and what waits here
    // and on the way.
    function noteRate(net, now, inMatch) {
        var log = Module.jkNet;
        // An upload after none for a while is another, with its own lines.
        // Parts that waited all that time (a link that stalled) are the same
        // upload, which keeps a line each PACE_NOTE_MS.
        if (up.emptied) {
            up.emptied = false;
            if (up.sentAt && now - up.sentAt > PACE_NOTE_MS) {
                up.notedRate = 0;
                up.looks = [0, 0, 0];
            }
        }
        var was = up.notedRate, since = now - up.notedAt;
        if (!inMatch) {
            if (was && up.paced && log && log.note)
                log.note('map upload: nobody else is playing now, so it goes unpaced');
            up.notedRate = 0;
            up.looks = [0, 0, 0];
            return;
        }
        up.notedLow = was ? Math.min(up.notedLow, up.rate) : up.rate;
        up.notedHigh = was ? Math.max(up.notedHigh, up.rate) : up.rate;
        var moved = (up.rate >= was * PACE_NOTE_MOVE || up.rate <= was / PACE_NOTE_MOVE) &&
                    (up.rate > up.bandHigh || up.rate < up.bandLow);
        if (was && since < PACE_NOTE_MS && (since < PACE_NOTE_SOON_MS || !moved))
            return;
        var low = up.notedLow, high = up.notedHigh;
        up.bandLow = low;
        up.bandHigh = high;
        var said = up.looks.map(function(n, i) {
            return n + [' a queue', ' no queue', ' no telling'][i] + (n && up.whys[i] ? ' (' + up.whys[i] + ')' : '');
        });
        up.notedRate = up.notedLow = up.notedHigh = up.rate;
        up.notedAt = now;
        up.looks = [0, 0, 0];
        if (!log || !log.note)
            return;
        var kb = function(n) { return Math.round(n / 1000); };
        var queued = 0, joiners = 0, onWay = 0;
        for (var id in up.queued) {
            if (up.queued[id] > 0) {
                queued += up.queued[id];
                joiners++;
            }
        }
        up.groups.forEach(function(g) {
            if (net && net.mapBacklog)
                onWay = Math.max(onWay, net.mapBacklog(g.to, g.via));
        });
        log.note('map upload paced at ' + kb(up.rate) + ' KB/s' + (was ? ' (was ' + kb(was) + ', ' + kb(low) + '-' + kb(high) + ' since)' : '') +
                 '; the link since the last line: ' + said.join(', ') + '; ' + kb(queued) + ' KB waiting for ' +
                 joiners + ' joiner(s), ' + kb(onWay) + ' KB on the way');
    }

    // Drops what waits for joiner id (all of them when not given): they left,
    // or (direct) their direct link closed, so they ask again through the
    // lobby. kind: only what waits of that kind.
    function forget(id, direct, kind) {
        up.groups.forEach(function(g) {
            if ((id === undefined || g.to === id) && !(direct && g.via === 'relay') &&
                (kind === undefined || g.kind === kind))
                removeGroup(g);
        });
    }

    function onHostFrame(from, type, data, via, kind) {
        if (from < 2)
            return;
        if (type === T_INFO_REQ) {
            var h = offers[kind];
            if (!h)
                return;
            if (h.info)
                sendInfo(kind, from, via);
            else if (h.waiting.length < 64)
                h.waiting.push({ id: from, via: via, kind: kind });
        } else if (type === T_STATUS && kind === KIND_NEXT) {
            var st = null;
            try { st = JSON.parse(new TextDecoder().decode(new Uint8Array(data, HEADER))); } catch (e) {}
            if (st && String(st.n).toLowerCase() === nextName && (st.s === STATE_BUSY || st.s === STATE_READY ||
                                                                  st.s === STATE_FAILED))
                nextStatus[from] = { s: st.s, p: typeof st.p === 'number' ? st.p : -1 };
        } else if (type === T_CHUNK_REQ && data.byteLength >= HEADER + 20) {
            var k = offerFor(new Uint8Array(data, HEADER, 8), kind);
            if (k === null)
                return;
            var o = offers[k];
            var v = new DataView(data);
            var size = v.getUint32(HEADER + 8, true);
            var first = v.getUint32(HEADER + 12, true);
            var count = Math.min(v.getUint32(HEADER + 16, true), MAX_CHUNKS_PER_REQ);
            if (size !== CHUNK_DIRECT && size !== CHUNK_RELAY)
                return;
            queueChunks(k, o, from, via, size, first, count);
        } else if (type === T_BLOCK_REQ && data.byteLength >= HEADER + 24) {
            var k = offerFor(new Uint8Array(data, HEADER, 8), kind);
            if (k === null)
                return;
            var o = offers[k];
            var v = new DataView(data);
            var first = v.getUint32(HEADER + 8, true);
            var count = Math.min(v.getUint32(HEADER + 12, true), MAX_BLOCKS_PER_REQ);
            var part = v.getUint32(HEADER + 16, true);
            var accept = new Uint8Array(data)[HEADER + 20];
            if (part !== PART_DIRECT && part !== PART_RELAY)
                return;
            // The lobby closes a socket that sends it more than 64 KiB at once.
            if (via === 'relay')
                part = PART_RELAY;
            var nb = Math.ceil(o.stream.length / BLOCK_BYTES);
            var b = first;
            for (; b < first + count && b < nb; b++)
                queueBlock(k, o, b, from, via, part, accept);
            // The next ones, squeezed while these go.
            for (var ahead = b; ahead < b + BLOCKS_AHEAD && ahead < nb && (accept & CODEC_DEFLATE); ahead++)
                block(o, ahead, accept);
        }
    }

    // ---- Joiner: one job per kind at a time, a map or a mod.

    var jobs = {};   // kind -> job
    var states = {}; // kind -> STATE_*

    // fields: label (shown on the panel) and whatever run needs. run(j) does
    // the work and resolves to the state to end in (STATE_READY if it returns
    // nothing), or throws fail(reason). j.messageFor(reason) can word a
    // failure its own way.
    function startJob(kind, fields, run) {
        var j = { kind: kind, done: false, onInfo: null, onChunk: null, timers: [] };
        for (var f in fields)
            j[f] = fields[f];
        jobs[kind] = j;
        states[kind] = STATE_BUSY;
        run(j).then(function(state) {
            finish(j, null, state);
        }, function(e) {
            finish(j, e && e.reason ? e.reason : 'error');
            if (!(e && e.reason))
                console.warn('OpenJKDF2: ' + (kind === KIND_MOD ? 'mod' : 'map') + ' download failed: ' + e);
        });
        return j;
    }

    function fetchMap(name, ext) {
        startJob(KIND_MAP, { name: name, ext: ext, label: name + '.' + ext }, runJob);
    }

    // A game watching a match (stdComm_WSRelay.c's view) gets the level the
    // host runs, by its GOB's SHA-256 from the feed's keyframe: the player's
    // own copy if it's that one, else one saved from an earlier game, else
    // the Level Library's, else the host's game's by way of the match's feed
    // (feed: its https address, and ask(fp) to ask it), as a mod comes
    // (mods.js fromHost). It shows no panel: onProgress(done, total, from)
    // says how far along the download is, from 'library' or 'host' (total 0
    // while the host's game is asked), and viewError() why it couldn't. With
    // another version of its own and none of the host's to be got, it
    // watches with its own.
    var viewJob = null;

    function viewFetch(name, ext, sha, onProgress, feed) {
        viewJob = startJob(KIND_MAP, {
            name: name, ext: ext, sha: sha, label: name + '.' + ext, quiet: true,
            feed: feed && typeof feed.url === 'string' && feed.url && typeof feed.ask === 'function' ? feed : null,
            messageFor: function(reason) { return viewMessageFor(reason, name, ext); },
            onProgress: onProgress || function() {}
        }, runViewJob);
    }

    function viewError() {
        return viewJob && viewJob.done && states[KIND_MAP] === STATE_FAILED && jobs[KIND_MAP] === viewJob ?
               viewJob.errorText || '' : '';
    }

    function viewMessageFor(reason, name, ext) {
        var level = 'this match\'s level (' + name + ')';
        var how = ' To watch it, put the same level in your game folder, or join a match on it once.';
        switch (reason) {
        case 'not-in-library':
            return "Your game files don't have " + level + ", and the Level Library doesn't have the host's version " +
                   'of it.' + how;
        case 'host-silent':
            return "Your game files don't have " + level + ", the Level Library doesn't have the host's version of it, " +
                   "and the host's game didn't send it. It may be on an older version of the page." + how;
        case 'host-stalled':
            return "The host's game stopped sending " + level + '. Try again in a minute.';
        case 'other-map':
            return 'The host is running a different level now.';
        case 'other-game':
            return 'The host sent a level for ' + (ext === 'goo' ? 'Jedi Knight' : 'Mysteries of the Sith') + '.';
        case 'corrupt':
        case 'mismatch':
            return 'The host\'s version of ' + level + " didn't arrive intact. Try again in a minute.";
        case 'missing-retail':
            return 'The host\'s version of ' + level + ' uses original ' + (ext === 'goo' ? 'Mysteries of the Sith' :
                   'Jedi Knight') + " files that your game files don't have.";
        case 'retail-changed':
            return 'Your game files have other versions of original files the host\'s version of ' + level + ' uses.';
        case 'cancelled':
            return '';
        }
        return undefined;
    }

    async function runViewJob(j) {
        if (!validEpisodeName(j.name) || !validExt(j.ext) || !/^[0-9a-f]{64}$/.test(j.sha))
            throw fail('bad-name');
        if (isRetailEpisode(j.name))
            return;
        var root = gameRoot();
        var local = findPath(root, 'episode/' + j.name + '.' + j.ext);
        if (local && !isFile(local))
            local = null;
        if (local && await sha256(fileBytes(local)) === j.sha)
            return;
        check(j);
        var game = j.ext === 'goo' ? 'mots' : 'jk1';
        var stored = null;
        try { stored = await store.get(game, j.name, j.sha); } catch (e) {}
        check(j);
        if (stored && await sha256(new Uint8Array(stored.data)) === (stored.meta.own || j.sha)) {
            check(j);
            install(root, j.name, j.ext, new Uint8Array(stored.data));
            console.log('OpenJKDF2: installed map ' + j.label + ' saved from an earlier game, to watch a match');
            return;
        }
        var site = null;
        if (Module.jkLibrary && Module.jkLibrary.gobFromSite) {
            try {
                site = await Module.jkLibrary.gobFromSite(game, j.sha, function(done, total) {
                    j.onProgress(done, total, 'library');
                });
            } catch (e) {
                console.log('OpenJKDF2: could not get ' + j.label + ' from the Level Library (' + (e && e.message || e) + ')');
            }
        }
        check(j);
        var from = 'the Level Library (' + (site && site.lib) + ')', extra = site ? { lib: site.lib } : null;
        if (!site && j.feed) {
            try {
                site = { bytes: await viewFromHost(j) };
                from = "the host's game";
            } catch (e) {
                if (!e || !e.reason || e.reason === 'cancelled' || !local)
                    throw e;
                console.log("OpenJKDF2: the host's game didn't send " + j.label + ' (' + e.reason + ')');
            }
            check(j);
        }
        if (!site) {
            if (local) {
                console.log("OpenJKDF2: watching with this player's own " + j.label + ", another version than the host's");
                return;
            }
            throw fail('not-in-library');
        }
        try {
            install(root, j.name, j.ext, site.bytes);
        } catch (e) {
            throw fail('install');
        }
        console.log('OpenJKDF2: installed map ' + j.label + ' from ' + from + ', to watch a match');
        store.put(game, j.name, j.ext, j.sha, site.bytes, extra).catch(function(e) {
            console.warn('OpenJKDF2: could not save map ' + j.label + ' for next time: ' + e);
        });
    }

    // The host's level from the host's game, by way of the match's feed
    // (feedGet), checked against the keyframe's SHA-256 as it's put back
    // together (fillRefs).
    async function viewFromHost(j) {
        var src = { base: j.feed.url + '/mod/' + j.sha + '/', ask: function() { j.feed.ask(j.sha); } };
        return feedGet(j, src, function(info) {
            if (info.ext !== j.ext)
                throw fail('other-game');
            checkInfo(info, MAX_MAP_BYTES);
            if (info.sha256 !== j.sha || String(info.name).toLowerCase() !== j.name.toLowerCase())
                throw fail('other-map');
        }, function(done, total) { j.onProgress(done, total, 'host'); });
    }

    // The next level of the host's playlist: got as a map is, quietly (the
    // engine's score screen shows how far along it is), and the host hears
    // how far along it is.
    function fetchNext(name, ext) {
        var old = jobs[KIND_NEXT];
        if (old && !old.done && old.name === name && old.ext === ext)
            return;
        if (old && !old.done)
            finish(old, 'cancelled');
        var j = startJob(KIND_NEXT, { name: name, ext: ext, label: name + '.' + ext, quiet: true, progress: -1,
                                      errorText: '', sentAt: 0 }, runJob);
        sendStatus(j, true);
    }

    function sendStatus(j, now) {
        if (j.kind !== KIND_NEXT)
            return;
        var t = Date.now();
        if (!now && t - j.sentAt < STATUS_MS)
            return;
        j.sentAt = t;
        var s = j.done ? states[KIND_NEXT] : STATE_BUSY;
        var json = new TextEncoder().encode(JSON.stringify({ n: j.name, s: s, p: s === STATE_READY ? 1 : j.progress }));
        var f = frame(T_STATUS, 1, json.length, KIND_NEXT);
        f.bytes.set(json, HEADER);
        send(1, f, directUp() ? 'direct' : 'relay');
    }

    // What a job shows the player: the panel, or for the playlist's next level
    // nothing (the engine shows it), only what it says to the host.
    function uiOf(j) {
        if (!j || !j.quiet)
            return ui;
        return {
            show: function() {},
            progress: function(done, total) {
                j.progress = total ? done / total : -1;
                sendStatus(j, false);
            },
            error: function(name, text) { j.errorText = text || ''; },
            notice: function() {},
            hide: function() {}
        };
    }

    function fail(reason) {
        var e = new Error(reason);
        e.reason = reason;
        return e;
    }

    function finish(j, reason, state) {
        if (j.done)
            return;
        j.done = true;
        j.timers.forEach(clearTimeout);
        if (j.cancel)
            j.cancel(fail(reason || 'done'));
        if (jobs[j.kind] !== j)
            return;
        if (!reason) {
            // A restart leaves its notice up, to be read after the restart.
            if (state !== STATE_RESTART)
                uiOf(j).hide();
            states[j.kind] = state || STATE_READY;
            sendStatus(j, true);
            return;
        }
        var text = messageFor(reason, j);
        if (text)
            uiOf(j).error(j.label, text, j.kind);
        else
            uiOf(j).hide();
        states[j.kind] = STATE_FAILED;
        if (j.kind === KIND_NEXT && !j.errorText)
            j.errorText = text || 'it was cancelled.';
        sendStatus(j, true);
        console.log('OpenJKDF2: ' + (j.kind === KIND_MOD ? 'mod ' : 'map ') + j.label + ' not installed: ' + reason);
    }

    function abort(reason, kind) {
        var j = jobs[kind || KIND_MAP];
        if (j && !j.done)
            finish(j, reason || 'cancelled');
    }

    function state(kind) {
        return kind in states ? states[kind] : STATE_READY;
    }

    function sleep(j, ms) {
        return new Promise(function(resolve, reject) {
            if (j.done)
                return reject(fail('cancelled'));
            j.cancel = reject;
            j.timers.push(setTimeout(resolve, ms));
        });
    }

    function check(j) {
        if (j.done)
            throw fail('cancelled');
    }

    function directUp() {
        var net = link();
        return !!(net && net.mapDirect && net.mapDirect(1));
    }

    // No direct link is coming when WebRTC is off in this browser.
    function directPossible() {
        var net = link();
        return !(net && net.rtcEnabled && !net.rtcEnabled());
    }

    // Gives a direct link that is still starting up a moment to come up.
    async function waitForDirect(j) {
        for (var waited = 0; waited < DIRECT_WAIT_MS && directPossible() && !directUp(); waited += 100)
            await sleep(j, 100);
    }

    function askInfo(j) {
        return new Promise(function(resolve, reject) {
            var started = Date.now();
            j.cancel = reject;
            j.onInfo = function(info) {
                j.onInfo = null;
                resolve(info);
            };
            function ask() {
                if (j.done || !j.onInfo)
                    return;
                if (Date.now() - started > INFO_TIMEOUT_MS)
                    return reject(fail('no-answer'));
                send(1, frame(T_INFO_REQ, 1, 0, j.kind), directUp() ? 'direct' : 'relay');
                j.timers.push(setTimeout(ask, INFO_RESEND_MS));
            }
            ask();
        });
    }

    // Checks what a host says about the file it offers before anything is
    // asked for: sizes and the hash have to make sense.
    function checkInfo(info, maxBytes) {
        if (!(info.size > 0 && info.size <= maxBytes))
            throw fail('too-big');
        if (!(info.refsBytes >= 4 && info.streamSize >= info.refsBytes &&
              info.streamSize <= info.size + 4 + MAX_REFS * REF_BYTES) || !/^[0-9a-f]{64}$/.test(info.sha256))
            throw fail('corrupt');
    }

    async function runJob(j) {
        if (!validEpisodeName(j.name) || !validExt(j.ext))
            throw fail('bad-name');
        var root = gameRoot();
        var local = findPath(root, 'episode/' + j.name + '.' + j.ext);
        if (isRetailEpisode(j.name)) {
            if (local)
                return;
            throw fail('retail-missing');
        }

        var checking = setTimeout(function() {
            if (!j.done)
                uiOf(j).show(j.label, "Checking the host's map...", function() { abort('cancelled'); }, KIND_MAP);
        }, CHECKING_UI_MS);
        j.timers.push(checking);
        var info;
        try {
            info = await askInfo(j);
        } catch (e) {
            // A host on an older build of the page never answers. Players who
            // have the map could join it before, so let them.
            if (e.reason === 'no-answer' && local && isFile(local)) {
                console.log("OpenJKDF2: the host didn't answer about its map, using this player's own " + j.label);
                return;
            }
            throw e;
        }
        if (info.status !== 'ok')
            throw fail(info.status);
        if (String(info.name).toLowerCase() !== j.name.toLowerCase())
            throw fail('other-map');
        if (info.ext !== j.ext)
            throw fail('other-game');
        checkInfo(info, MAX_MAP_BYTES);

        if (local && isFile(local) && FS().stat(local).size === info.size &&
            await sha256(fileBytes(local)) === info.sha256)
            return;
        check(j);

        var game = j.ext === 'goo' ? 'mots' : 'jk1';
        var stored = null;
        try { stored = await store.get(game, j.name, info.sha256); } catch (e) {}
        check(j);
        // A map saved with the player's own versions of original files is
        // checked against what was saved (own), not the host's file.
        if (stored && await sha256(new Uint8Array(stored.data)) === (stored.meta.own || info.sha256)) {
            check(j);
            install(root, j.name, j.ext, new Uint8Array(stored.data));
            console.log('OpenJKDF2: installed map ' + j.label + ' saved from an earlier game');
            return;
        }

        clearTimeout(checking);

        // The playlist's next level, when it's a Level Library level: from
        // the site, which the host doesn't have to upload it to everyone for.
        if (j.kind === KIND_NEXT && Module.jkLibrary && Module.jkLibrary.gobFromSite) {
            var site = null;
            try {
                site = await Module.jkLibrary.gobFromSite(game, info.sha256, function(done, total) {
                    uiOf(j).progress(done, total);
                });
            } catch (e) {
                console.log('OpenJKDF2: the site had no copy of ' + j.label + ' (' + (e && e.message || e) + '), getting it from the host');
            }
            check(j);
            if (site) {
                try {
                    install(root, j.name, j.ext, site.bytes);
                } catch (e) {
                    throw fail('install');
                }
                console.log('OpenJKDF2: installed map ' + j.label + ' from the Level Library (' + site.lib + ')');
                store.put(game, j.name, j.ext, info.sha256, site.bytes, { lib: site.lib }).catch(function(e) {
                    console.warn('OpenJKDF2: could not save map ' + j.label + ' for next time: ' + e);
                });
                return;
            }
            j.progress = -1;
        }

        uiOf(j).show(j.label, 'Connecting to the host...', function() { abort('cancelled'); }, KIND_MAP);
        await waitForDirect(j);
        var bytes = await receive(j, info, retailSources(root, j.ext), true);
        try {
            install(root, j.name, j.ext, bytes);
        } catch (e) {
            throw fail('install');
        }
        console.log('OpenJKDF2: installed map ' + j.label + ' from the host' +
                    (j.own ? ", with this player's own versions of " + j.own + ' original files it bundles' : ''));
        (async function() {
            var extra = j.own ? { own: await sha256(bytes) } : null;
            await store.put(game, j.name, j.ext, info.sha256, bytes, extra);
        })().catch(function(e) {
            console.warn('OpenJKDF2: could not save map ' + j.label + ' for next time: ' + e);
        });
    }

    // Gets the host's file, in blocks from a host that sends them (it says z)
    // or else in chunks, put back together and checked. With own (a map),
    // original files the joiner only has other versions of are left out of
    // it, and j.own says how many.
    async function receive(j, info, retailSources, own) {
        var result;
        if (info.z === BLOCK_BYTES) {
            var rb = rebuilder(info, retailSources, own);
            bulk(true);
            try {
                await downloadBlocks(j, info, rb.put);
            } finally {
                bulk(false);
            }
            result = await rb.finish();
        } else {
            var stream = await download(j, info, directUp() ? CHUNK_DIRECT : CHUNK_RELAY);
            result = await rebuild(info, stream, retailSources, own);
        }
        if (!result.ok)
            throw fail(result.reason);
        check(j);
        j.own = result.own || 0;
        return result.bytes;
    }

    // The ways to the host a block can be asked for on now: the map channel
    // and the extra links for transfers (net.mapLanes), or the relay.
    function lanes() {
        var net = link();
        if (net && net.mapLanes) {
            var l = net.mapLanes(1);
            if (l.length)
                return l;
        } else if (directUp()) {
            return ['direct'];
        }
        return ['relay'];
    }

    // Asks the network code for the extra links to the host while a transfer
    // runs, and lets them go after it.
    function bulk(on) {
        var net = link();
        if (net && net.mapBulk)
            net.mapBulk(1, on);
    }

    // Unsqueezes a block, which has to come out exactly size bytes.
    async function inflate(z, size) {
        var ds = new DecompressionStream('deflate-raw');
        var w = ds.writable.getWriter();
        w.write(z).catch(function() {});
        w.close().catch(function() {});
        var r = ds.readable.getReader();
        var out = new Uint8Array(size);
        var n = 0;
        for (;;) {
            var x;
            try {
                x = await r.read();
            } catch (e) {
                throw fail('corrupt');
            }
            if (x.done)
                break;
            if (n + x.value.length > size) {
                r.cancel().catch(function() {});
                throw fail('corrupt');
            }
            out.set(x.value, n);
            n += x.value.length;
        }
        if (n !== size)
            throw fail('corrupt');
        return out;
    }

    // Bytes a second over the last few seconds.
    function rateMeter() {
        var marks = [];
        return function(bytes) {
            var now = Date.now();
            marks.push({ t: now, bytes: bytes });
            while (marks.length > 2 && now - marks[1].t > 3000)
                marks.shift();
            var span = now - marks[0].t;
            return span >= 500 ? (bytes - marks[0].bytes) * 1000 / span : 0;
        };
    }

    // Parts of a block come in whole units of 16 KiB, which both part sizes
    // are, so a block asked for again on another way fills in what's missing.
    var UNIT = 16 * 1024;

    // Pulls the stream in blocks, a few at a time on each way to the host,
    // and hands each to put(offset, bytes) once it's in and unsqueezed. A
    // block that stops coming (its link dropped) is asked for again.
    function downloadBlocks(j, info, put) {
        return new Promise(function(resolve, reject) {
            var total = info.streamSize;
            var nb = Math.ceil(total / BLOCK_BYTES);
            var id = idOf(info.sha256);
            var accept = typeof DecompressionStream !== 'undefined' ? CODEC_DEFLATE : CODEC_STORED;
            var next = 0;
            var redo = [];
            var have = new Uint8Array(nb);
            var asked = new Map(); // block -> { lane, at }
            var parts = new Map(); // block -> { zlen, codec, buf, units, left }
            var done = 0, bytes = 0;
            var lastProgress = Date.now();
            var meter = rateMeter();
            var via = 'direct';

            j.cancel = reject;

            function rawSize(b) {
                return Math.min(BLOCK_BYTES, total - b * BLOCK_BYTES);
            }

            function ask(b, lane) {
                var f = frame(T_BLOCK_REQ, 1, 24, j.kind);
                f.bytes.set(id, HEADER);
                f.view.setUint32(HEADER + 8, b, true);
                f.view.setUint32(HEADER + 12, 1, true);
                f.view.setUint32(HEADER + 16, lane === 'relay' ? PART_RELAY : PART_DIRECT, true);
                f.bytes[HEADER + 20] = accept;
                var went = send(1, f, lane);
                if (!went)
                    return false;
                asked.set(b, { lane: went, at: Date.now() });
                via = went;
                return true;
            }

            // One block at a time to the way with the fewest out, so a small
            // file still spreads over them all.
            function pump() {
                var busy = {};
                var open = lanes();
                for (var lane of open)
                    busy[lane] = 0;
                asked.forEach(function(a) { busy[a.lane] = (busy[a.lane] || 0) + 1; });
                for (;;) {
                    var best = null;
                    for (var lane of open) {
                        if (busy[lane] < (lane === 'relay' ? BLOCKS_RELAY : BLOCKS_DIRECT) &&
                            (best === null || busy[lane] < busy[best]))
                            best = lane;
                    }
                    if (best === null)
                        return;
                    var again = redo.length > 0;
                    var b = again ? redo.shift() : next < nb ? next++ : -1;
                    if (b < 0)
                        return;
                    if (have[b] || asked.has(b))
                        continue;
                    if (!ask(b, best)) {
                        if (again)
                            redo.unshift(b);
                        else
                            next--;
                        return;
                    }
                    busy[best]++;
                }
            }

            function finished(b, out) {
                if (j.done)
                    return;
                put(b * BLOCK_BYTES, out);
                done++;
                bytes += out.length;
                uiOf(j).progress(bytes, total, via, meter(bytes));
                if (done === nb) {
                    j.onBlock = null;
                    resolve();
                }
            }

            j.onBlock = function(data) {
                if (data.byteLength < HEADER + BLOCK_HEADER || !sameId(new Uint8Array(data, HEADER, 8), id))
                    return;
                var v = new DataView(data);
                var b = v.getUint32(HEADER + 8, true);
                var zlen = v.getUint32(HEADER + 12, true);
                var at = v.getUint32(HEADER + 16, true);
                var codec = new Uint8Array(data)[HEADER + 20];
                var len = data.byteLength - HEADER - BLOCK_HEADER;
                if (b >= next || have[b])
                    return;
                var raw = rawSize(b);
                if (codec === CODEC_STORED ? zlen !== raw : codec !== CODEC_DEFLATE || !accept || !zlen || zlen >= raw)
                    return;
                if (at % UNIT || !len || at + len > zlen || (len % UNIT && at + len !== zlen))
                    return;
                var p = parts.get(b);
                if (!p || p.zlen !== zlen || p.codec !== codec) {
                    var units = Math.ceil(zlen / UNIT);
                    p = { zlen: zlen, codec: codec, buf: new Uint8Array(zlen), units: new Uint8Array(units), left: units };
                    parts.set(b, p);
                }
                p.buf.set(new Uint8Array(data, HEADER + BLOCK_HEADER, len), at);
                for (var u = at / UNIT; u < Math.ceil((at + len) / UNIT); u++) {
                    if (!p.units[u]) {
                        p.units[u] = 1;
                        p.left--;
                    }
                }
                lastProgress = Date.now();
                var a = asked.get(b);
                if (a)
                    a.at = lastProgress;
                if (p.left)
                    return;
                have[b] = 1;
                asked.delete(b);
                parts.delete(b);
                (codec === CODEC_DEFLATE ? inflate(p.buf, raw) : Promise.resolve(p.buf)).then(function(out) {
                    finished(b, out);
                }).catch(function(e) {
                    reject(e && e.reason ? e : fail('corrupt'));
                });
                pump();
            };

            // Blocks on a way that's gone, or that haven't moved for a while,
            // are asked for again.
            function tick() {
                if (j.done || done === nb)
                    return;
                var now = Date.now();
                if (now - lastProgress > STALL_MS)
                    return reject(fail('stalled'));
                var open = lanes();
                asked.forEach(function(a, b) {
                    if (open.indexOf(a.lane) < 0 || now - a.at > CHUNK_RESEND_MS) {
                        asked.delete(b);
                        redo.push(b);
                    }
                });
                redo.sort(function(x, y) { return x - y; });
                pump();
                j.timers.push(setTimeout(tick, 250));
            }

            uiOf(j).progress(0, total, via, 0);
            pump();
            tick();
        });
    }

    // Pulls the stream in numbered chunks, a window at a time, asking again
    // for chunks that don't come (lost when the link changed).
    function download(j, info, chunkSize) {
        return new Promise(function(resolve, reject) {
            var total = info.streamSize;
            var n = Math.ceil(total / chunkSize);
            var id = idOf(info.sha256);
            var buf = new Uint8Array(total);
            var got = new Uint8Array(n);
            var received = 0, bytes = 0, next = 0;
            var asked = new Map(); // chunk -> time asked
            var window = Math.max(4, Math.floor(WINDOW_BYTES / chunkSize));
            // Asking for half a window at a time keeps requests to a few per
            // window: through the relay each one counts against the lobby's
            // daily limit.
            var batch = Math.max(1, Math.floor(window / 2));
            var lastProgress = Date.now();
            var via = directUp() ? 'direct' : 'relay';

            j.cancel = reject;

            function ask(first, count) {
                var f = frame(T_CHUNK_REQ, 1, 20, j.kind);
                f.bytes.set(id, HEADER);
                f.view.setUint32(HEADER + 8, chunkSize, true);
                f.view.setUint32(HEADER + 12, first, true);
                f.view.setUint32(HEADER + 16, count, true);
                via = send(1, f, directUp() ? 'direct' : 'relay') || via;
                var now = Date.now();
                for (var i = first; i < first + count; i++)
                    asked.set(i, now);
            }

            function pump() {
                while (next < n) {
                    var count = Math.min(n - next, window - asked.size, MAX_CHUNKS_PER_REQ);
                    if (count < Math.min(batch, n - next))
                        break;
                    ask(next, count);
                    next += count;
                }
            }

            j.onChunk = function(data) {
                if (data.byteLength < HEADER + 12 || !sameId(new Uint8Array(data, HEADER, 8), id))
                    return;
                var i = new DataView(data).getUint32(HEADER + 8, true);
                var len = Math.min(chunkSize, total - i * chunkSize);
                if (i >= n || got[i] || data.byteLength !== HEADER + 12 + len)
                    return;
                buf.set(new Uint8Array(data, HEADER + 12, len), i * chunkSize);
                got[i] = 1;
                asked.delete(i);
                received++;
                bytes += len;
                lastProgress = Date.now();
                uiOf(j).progress(bytes, total, via);
                if (received === n) {
                    j.onChunk = null;
                    resolve(buf);
                } else {
                    pump();
                }
            };

            function tick() {
                if (j.done || received === n)
                    return;
                var now = Date.now();
                if (now - lastProgress > STALL_MS)
                    return reject(fail('stalled'));
                var late = [];
                asked.forEach(function(t, i) { if (now - t > CHUNK_RESEND_MS) late.push(i); });
                late.sort(function(a, b) { return a - b; });
                for (var k = 0; k < late.length; ) {
                    var first = late[k], count = 1;
                    while (k + count < late.length && late[k + count] === first + count && count < MAX_CHUNKS_PER_REQ)
                        count++;
                    ask(first, count);
                    k += count;
                }
                j.timers.push(setTimeout(tick, 500));
            }

            uiOf(j).progress(0, total, via);
            pump();
            tick();
        });
    }

    function onJoinerFrame(from, type, data, kind) {
        var j = jobs[kind];
        if (from !== 1 || !j || j.done)
            return;
        if (type === T_INFO && j.onInfo) {
            var info = null;
            try { info = JSON.parse(new TextDecoder().decode(new Uint8Array(data, HEADER))); } catch (e) {}
            if (info && typeof info.status === 'string')
                j.onInfo(info);
        } else if (type === T_CHUNK && j.onChunk) {
            j.onChunk(data);
        } else if (type === T_BLOCK && j.onBlock) {
            j.onBlock(data);
        }
    }

    // Frames from player `from`, over the map data channel ('direct') or the
    // lobby ('relay').
    function onFrame(from, data, via) {
        if (!isFrame(data))
            return;
        var b = new Uint8Array(data, 12, 3);
        if (b[1] !== VERSION || (b[2] !== KIND_MAP && b[2] !== KIND_MOD && b[2] !== KIND_NEXT))
            return;
        if (b[0] === T_INFO_REQ || b[0] === T_CHUNK_REQ || b[0] === T_BLOCK_REQ || b[0] === T_STATUS)
            onHostFrame(from, b[0], data, via, b[2]);
        else
            onJoinerFrame(from, b[0], data, b[2]);
    }

    Module.jkMaps = {
        lib: lib,
        isFrame: isFrame,
        onFrame: onFrame,
        host: host,
        unhost: unhost,
        // The network code: send what may go now, and drop what waits for a
        // player who left.
        pump: pump,
        forget: forget,
        // What the uploads are doing, for tests.
        uploads: function() {
            return { rate: up.rate, groups: up.groups.size, queued: Object.assign({}, up.queued), sent: up.sent };
        },
        fetch: fetchMap,
        // Watching a match (stdComm_WSRelay.c): the GOB's SHA-256 the host's
        // keyframes carry, '' for a retail level or until it's hashed for
        // joiners (host), and getting it as a watcher.
        hostedSha: function(name, ext) {
            var o = offers[KIND_MAP];
            return o && o.info && o.info.status === 'ok' && o.name === String(name).toLowerCase() && o.ext === ext ?
                   o.info.sha256 : '';
        },
        viewFetch: viewFetch,
        viewError: viewError,
        // The host's side of it: a game watching asked the feed for the
        // level by its SHA-256 (fp), and the host's game puts it there
        // (feedUp, once for a while). true when fp is the level it's on;
        // false when it isn't, and it may be the host's mod (mods.js feedUp).
        feedUp: function(feedUrl, fp, alive) {
            var o = offers[KIND_MAP];
            if (!(o && o.info && o.info.status === 'ok' && o.info.sha256 === fp))
                return false;
            feedUp(KIND_MAP, feedUrl, fp, alive);
            return true;
        },
        abort: function(reason) { abort(reason, KIND_MAP); },
        state: function() { return state(KIND_MAP); },
        // The next level of the host's playlist (src/Main/jkPlaylist.c).
        next: {
            host: hostNext,
            waiting: waitingFor,
            fetch: fetchNext,
            state: function() { return state(KIND_NEXT); },
            // How far along this player is, 0 to 1, or -1 when not known.
            progress: function() {
                var j = jobs[KIND_NEXT];
                return state(KIND_NEXT) === STATE_READY ? 1 : j ? j.progress : -1;
            },
            // Why it couldn't be got, for the score screen.
            error: function() {
                var j = jobs[KIND_NEXT];
                return state(KIND_NEXT) === STATE_FAILED && j ? j.errorText : '';
            }
        },
        // What mods.js builds on to send the host's mod the same way.
        core: {
            KIND_MOD: KIND_MOD, STATE_BUSY: STATE_BUSY, STATE_READY: STATE_READY,
            STATE_FAILED: STATE_FAILED, STATE_RESTART: STATE_RESTART,
            CHUNK_DIRECT: CHUNK_DIRECT, CHUNK_RELAY: CHUNK_RELAY, CHECKING_UI_MS: CHECKING_UI_MS,
            offer: offer, withdraw: withdraw, startJob: startJob, abort: abort, state: state,
            feedUp: feedUp, feedGet: feedGet,
            askInfo: askInfo, checkInfo: checkInfo, download: download, receive: receive,
            waitForDirect: waitForDirect, directUp: directUp, fail: fail, check: check, sleep: sleep, ui: ui,
            findPath: findPath, isFile: isFile, fileBytes: fileBytes, gameRoot: gameRoot,
            retailSources: retailSources, makeStore: makeStore,
            // What library.js saves the levels it gets with.
            store: store, install: install, validEpisodeName: validEpisodeName, validExt: validExt
        }
    };

    // Maps saved from earlier games go into episode/ before the engine starts,
    // after the page has written the picked folder (its preRun runs first).
    // Not for the free demo (the page's Module.jkDemo), which plays only its
    // own level: the maps this browser saved for the full game would be on
    // its Host screen, and nobody playing the demo could load them.
    if (typeof indexedDB !== 'undefined') {
        Module.preRun = Module.preRun || [];
        if (typeof Module.preRun === 'function')
            Module.preRun = [Module.preRun];
        Module.preRun.push(function() {
            if (Module.jkDemo)
                return;
            var mots = (Module['arguments'] || []).indexOf('-motsCompat') >= 0;
            Module.addRunDependency('jk-maps');
            installStoredMaps(mots ? '/mots' : '/jk1', mots ? 'mots' : 'jk1').then(function(names) {
                if (names.length)
                    console.log('OpenJKDF2: added maps saved from earlier games: ' + names.join(', '));
            }, function(e) {
                console.warn('OpenJKDF2: could not load maps saved from earlier games: ' + e);
            }).finally(function() {
                Module.removeRunDependency('jk-maps');
            });
        });
    }
})();
