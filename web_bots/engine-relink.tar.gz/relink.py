#!/usr/bin/env python3
"""Activate Emscripten 6.0.12, modify libsmacker, then run this script."""
from pathlib import Path
import json, subprocess
root = Path(__file__).resolve().parent
config = json.loads((root / "link.json").read_text())
for source, linked_object in config["smacker_objects"].items():
    subprocess.run(["emcc", *config["compile_args"], "-c", "libsmacker/" + source,
                    "-o", linked_object], cwd=root, check=True)
subprocess.run(config["link"], cwd=root, check=True)
print(root / "openjkdf2.wasm")
